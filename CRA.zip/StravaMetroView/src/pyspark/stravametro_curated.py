from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.functions import regexp_replace, regexp_extract, expr, when, lit
from pyspark.sql.types import StringType, IntegerType
import os, subprocess
from pyspark.sql.functions import to_date,concat


sparksession = (SparkSession
                .builder
                .appName("Strava_Metro-Curated")
                .enableHiveSupport()
                .getOrCreate())




df_cycle_cnt = sparksession.sql("SELECT *  FROM strava_metroview_landing.strava_cycle_count")
df_cycle_cnt = df_cycle_cnt.withColumnRenamed('reverse_average_speed\r', 'reverse_average_speed')
df_cycle_cnt = df_cycle_cnt.withColumnRenamed('date', 'strava_date')
df_cycle_ref= sparksession.sql("SELECT *  FROM strava_metroview_landing.strava_cycle_reference")

df_cycle_curated =df_cycle_cnt.join(df_cycle_ref,df_cycle_cnt.edge_uid == df_cycle_ref.osmID) 
df_cycle_curated = df_cycle_curated.drop(df_cycle_curated.edgeUID)
df_cycle_curated = df_cycle_curated.drop(df_cycle_curated.osmID)
df_cycle_curated.write.saveAsTable("strava_metroview_curated.strava_metro_cycle_cnt", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Curated/strava_metro_cycle_cnt")


df_ped_cnt = sparksession.sql("SELECT *  FROM strava_metroview_landing.strava_pedestrians_count")
df_ped_cnt = df_ped_cnt.withColumnRenamed('reverse_average_speed\r', 'reverse_average_speed')
df_ped_cnt = df_ped_cnt.withColumnRenamed('date', 'strava_date')
df_ped_ref= sparksession.sql("SELECT *  FROM strava_metroview_landing.strava_pedestrians_reference")

df_ped_curated =df_ped_cnt.join(df_ped_ref,df_ped_cnt.edge_uid == df_ped_ref.osmID) 
df_ped_curated = df_ped_curated.drop(df_ped_curated.edgeUID)
df_ped_curated = df_ped_curated.drop(df_ped_curated.osmID)
df_ped_curated.write.saveAsTable("strava_metroview_curated.strava_metro_pedestrians_cnt", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Curated/strava_metro_pedestrians_cnt")
