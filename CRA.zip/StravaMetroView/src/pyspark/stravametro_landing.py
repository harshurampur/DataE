from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType
import os, subprocess
from pyspark.sql.functions import sha2


sparksession = (SparkSession
                .builder
                .appName("Strava_Metro_View")
                .enableHiveSupport()
                .getOrCreate())



def checkSourceFilecsv():
    ret = 0
    check_file_command = "hadoop fs -ls /Data/CMTEDD/OCDO/StravaMetroView/SourceData/ | grep .csv| wc -l"
    ret = int(subprocess.check_output(check_file_command, shell=True))
    return ret


def checkSourceFile():
    ret = 0
    check_file_command = "hadoop fs -ls /Data/CMTEDD/OCDO/StravaMetroView/SourceData/*/ | grep .csv | wc -l"
    ret = int(subprocess.check_output(check_file_command, shell=True))
    return ret

# Read  strava csv
if checkSourceFilecsv() > 0:
    df_strava_metro_ride = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/CMTEDD/OCDO/StravaMetroView/SourceData/cycle.csv")
    df_strava_metro_ride = df_strava_metro_ride.select("linetype","edgeUID", "osmID", "start_linestring_long", "end_linestring_long","start_linestring_lat","end_linestring_lat" )
    #df_strava_metro_ride= df_strava_metro_ride.withColumn("edgeUID", df_strava_metro_ride["edgeUID"].cast(StringType()))
    df_strava_metro_ride.write.saveAsTable("strava_metroview_landing.strava_cycle_reference", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_cycle_reference")
    


    df_strava_metro_ped = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/CMTEDD/OCDO/StravaMetroView/SourceData/pedestrian.csv")
    df_strava_metro_ped = df_strava_metro_ped.select("linetype","edgeUID", "osmID", "start_linestring_long", "end_linestring_long","start_linestring_lat","end_linestring_lat" )
    df_strava_metro_ped.write.saveAsTable("strava_metroview_landing.strava_pedestrians_reference", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_pedestrians_reference")

if checkSourceFile() > 0:
    df_strava_metro_ride_count = sparksession.read.option("header",True).option("inferSchema", "true").option("multiline","true").csv("/Data/CMTEDD/OCDO/StravaMetroView/SourceData/Cycle/*.csv")
    df_strava_metro_ride_count.write.saveAsTable("strava_metroview_landing.strava_cycle_count", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_cycle_count")

    df_strava_metro_ped_count = sparksession.read.option("header",True).option("inferSchema", "true").option("multiline","true").csv("/Data/CMTEDD/OCDO/StravaMetroView/SourceData/Pedestrians/*.csv")
    df_strava_metro_ped_count.write.saveAsTable("strava_metroview_landing.strava_pedestrians_count", format="parquet", mode="overwrite", path="/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_pedestrians_count")