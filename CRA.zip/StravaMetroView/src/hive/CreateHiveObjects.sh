hive -e '
CREATE DATABASE IF NOT EXISTS strava_metroview_landing;

USE strava_metroview_landing;
	
CREATE EXTERNAL TABLE IF NOT EXISTS strava_cycle_reference(
	linetype STRING,
    edgeUID INT,
	osmID INT,
	start_linestring_long DECIMAL(9,6),
	start_linestring_lat DECIMAL(9,6),
    end_linestring_long DECIMAL(9,6),
	end_linestring_lat DECIMAL(9,6)
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_cycle_reference/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");


CREATE EXTERNAL TABLE IF NOT EXISTS strava_pedestrians_reference(
	linetype STRING,
    edgeUID INT,
	osmID INT,
	start_linestring_long DECIMAL(9,6),
	start_linestring_lat DECIMAL(9,6),
    end_linestring_long DECIMAL(9,6),
	end_linestring_lat DECIMAL(9,6)
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/CMTEDD/OCDO/StravaMetroView/Landing/strava_pedestrians_reference/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");


CREATE DATABASE IF NOT EXISTS strava_metroview_curated;
'