#!/bin/bash
log_dir=$1
currentDateTime=$(date)
# strCurrentDateTime=$(date -d "$currentDateTime" +'%Y-%m-%d %H:%M:%S')
log_file="$log_dir/CRA_StravaMetro_$(date -d "$currentDateTime" +'%Y%m%d%H%M%S').log"

echo "Running StravaMetroView Processing" >> "$log_file"

Source_Path_processing="{{ cycle_path }}"
isEmpty=$(hadoop fs -ls  $Source_Path_processing*.csv -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Start Source Processing" >> "$log_file"
    source /opt/miniconda3/bin/activate /home/mapr/envs/{{ conda_env }};
    python /tmp/CRA/StravaMetroView/get_src_data.py >> "$log_file"
    source /opt/miniconda3/bin/deactivate
    echo "Source Processing Completed" >> "$log_file"
else
    echo "Not found csvs for processing" >> "$log_file"
fi

Source_Path_geojson="{{ cycle_path }}"
isEmpty=$(hadoop fs -ls  $Source_Path_geojson*.geojson -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Start converting to json" >> "$log_file"
    source /opt/miniconda3/bin/activate /home/mapr/envs/{{ conda_env }};
    python /tmp/CRA/StravaMetroView/convert_geojson.py >> "$log_file"
    source /opt/miniconda3/bin/deactivate
    echo "Processing Completed" >> "$log_file"
else
    echo "Not found geojson for processing" >> "$log_file"
fi


sleep 10s

echo "Running Landing Strava Metro" >> "$log_file"
/opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/StravaMetroView/pyspark/stravametro_landing.py 2>&1>> "$log_file"
echo "Landing Strava Metro Completed" >> "$log_file"


sleep 10s

echo "Running Curation Strava Metro" >> "$log_file"
/opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/StravaMetroView/pyspark/stravametro_curated.py 2>&1>> "$log_file"
echo "Curation Strava Metro Completed" >> "$log_file"