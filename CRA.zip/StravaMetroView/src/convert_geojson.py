#! /usr/bin/env python

from glob import glob
import pandas as pd
import json
import os


source_path = "{{ source_path }}"


def geojsontojson():
    files=glob(source_path + "*/*.geojson")
    for infile in files:
        if "Cycle" in infile:
            infile_csv = source_path + "cycle.csv"
        else:
            infile_csv = source_path + "pedestrian.csv"
        with open(infile) as f:
            geo_json = json.load(f)
            data =  pd.io.json.json_normalize(geo_json['features'])
            data.columns = ["coordinates","linetype","edgeUID","osmID","type"]
            df_full = data.coordinates.apply(pd.Series)
            df_full.columns = ["start_linestring", "end_Linestring"]
            df_start =df_full.start_linestring.apply(pd.Series)
            df_end = df_full.end_Linestring.apply(pd.Series)
            df_start.columns =["start_linestring_long", "start_linestring_lat"]
            df_end.columns =["end_linestring_long", "end_linestring_lat"]
            df_result =  pd.concat([data,df_start, df_end], axis=1)
            df_result = df_result.drop('coordinates', 1)
            df_result = df_result.drop('type', 1)
            df_result.to_csv(infile_csv)
        f.close()
        data = pd.DataFrame(columns = ["coordinates","linetype","edgeUID","osmID","type"])
    return


geojsontojson()
