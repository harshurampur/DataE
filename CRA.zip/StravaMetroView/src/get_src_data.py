#! /usr/bin/env python

import pandas as pd
import csv
import time
import glob
import os
import geopandas
from os.path import basename

source_path="{{ source_path }}"
cycle_path = "{{ cycle_path }}"
ped_path = "{{ pedestrian_path }}"


def convertTogeojson():
    
    for infile in glob.glob(source_path+"*/"+'*.shp'):
        infile_basepath = os.path.splitext(infile)[0]
        infile_gjson = os.path.splitext(infile_basepath)[0]+ ".geojson"
        sh = geopandas.read_file(infile)
        sh.to_file(infile_gjson, driver='GeoJSON')
        print("Finished Writing geojson file")
    return

convertTogeojson()


