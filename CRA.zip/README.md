# Introduction 
CRA Place Success Dashboard

# Getting Started
Each folders within CRA repo has information and measures used for dashboard

**PlaceSuccess** folder is the place where all the drill views are loaded from different folders. It is the final stage to put in the drill views after the curation

The folders are:
1.	BluetoothTraffic
2.	EventsACT
3.	MyWay
4.	PlaceAudit
5.  Reference
6.  StravaMetroView
7.  TrafficVolume
8.  PlaceSuccess


# Bluetooth Traffic 
Real Time traffic Information
Bluetooth detectors placed in certain roads to monitor traffic flow that provides network-wide performance indicators in real time. Details about congestion & travel time can be accessed via APIs provided in the dataset link below:

- [Bluetooth API Reference](https://www.data.act.gov.au/dataset/realtime-traffic/cjkg-rvmu)

In the datalake the road links data are generated on a frequency basis every day from 7am, 8am, 9am, 10am and in the afternoon 2pm,3pm,4pm,5pm using **oozie** scheduler 

the link for API reference is updated every 5 secs

- [Link Congestion API](http://data.addinsight.com/ACT/links_congested_prop_stats_geo.json)

## Update on the __WIP__:


-  Only the source files are uploaded to the datalake in __TCCS/TrafficData/Sourcedata__ in the format of yyyy-mm-dd_traffic.csv where the    times are appended in each day file.

-  Oozie scheduled untill **__start_time: "2020-07-01T00:00Z" end_time: "2020-12-31T00:00Z"__**

-  Only released in test.

- Release
 
# EventsACT 
Free events from EVENTS ACT API 

For events ACT,the events are pulled from the [Australian Tourism Data Warehouse](https://atdw.com.au/) as a rolling live data.
Please refer the link for developer document API reference

- [Document API Reference](https://developer.atdw.com.au/ATDWO-api.html)

## Update on Release

-   The reference key in variable in the release.
-   The events ACT historic data is provided by the EPSDD directorate.
-   The excel file is uploaded to **eventsact_historic** directory
-   Events API data on datalake is updated in **maprDBjson** every day in production
 
# MyWay
MYWAY Tap on and Tap offs for each individual day and time to detect the footfall and travel for Access and Mobility indicator.

Currently only received data for May01 to May24 and have been added to the datalake in **TCCS/MyWay/SourceData**

## Update on __WIP__:

-   Only May files have been loaded to Datalake
-   Waiting for approval for streaming the data into Datalake on a weekly basis.

# StravaMetroView
Strava metro view data to determine Access and Mobility Indicator for pedestrian access and cyclists.

More information [strava metro view website](https://metroview.strava.com/)

You need to register first to access the map and data online.(Registration could take up to 2 weeks to access the content)


## Update on Release

-   Currently only a Intersection of Constitution Ave and Coranderrk St data for 2019 is downloaded and uploaded to the datalake.
-   There is no geospatial information provided in the dataset, however the shape files.
-   Used Conda env to convert the shape files to geojson and then to csv to get the reference for the geocodes for that intersection.
-   Both Pedestrians and Cyclist information is added into the hive landing table.

# TrafficVolume
This dataset contains historic traffic volume of vehicles passing through road detectors from 1st Jan 2019 to 31st Dec 2019. There are 14 detectors at this road intersection. The schematic diagram of all those detectors are available at [link](https://www.data.act.gov.au/Transport/Schematics-of-Road-Detectors/e6rb-gbiq)

The historic data can be downloaded from the [link](https://www.data.act.gov.au/Transport/Historic-Traffic-Volume-2019-Constitution-Ave-Cora/w45w-hysi)

Only one intersection data is now available to download - (Constitution Ave & Coranderrk St)


## Update on Release

-   Currently only a Intersection of Constitution Ave and Coranderrk St data for 2019 is downloaded and uploaded to the datalake.
-   There is no geospatial information provided in the dataset, **traffic_volume_reference** boundaries was determined using the latlon         cordinates using google and [geojson](https://geojson.io) to determin the centroid latitudes, longitudes,suburb information and map the .

