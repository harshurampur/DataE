from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType

sparksession = (SparkSession
                .builder
                .appName("CRA-PlaceAudit-hive")
                .enableHiveSupport()
                .getOrCreate())

# Read Suburb csv 
df_measurevals_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Landing/measurevalues.csv")
df_measurevals = df_measurevals_raw.select(col("RowID").alias("pid"),'MeasureName','PrecinctName', 'ReportingPeriod', 'FormatLookupType', 'AggregrationLookupType', 'MeasureValueNumeric','MeasureValueString','EffectiveFromDate', 'EffectiveToDate','CurrentFlag','HasDetailFlag','AuditPlanName','MeasureOtherFlag','MeasureOtherDescription','ValueProvenanceDescription','CreatedDateTime','UpdatedDateTime')
df_measurevals = df_measurevals.withColumnRenamed('MeasureName','measure_nm')
df_measurevals = df_measurevals.withColumnRenamed('PrecinctName','precinct_nm')
df_measurevals = df_measurevals.withColumnRenamed('ReportingPeriod','reporting_prd')
df_measurevals = df_measurevals.withColumnRenamed('FormatLookupType','format_lkup_typ')
df_measurevals = df_measurevals.withColumnRenamed('AggregrationLookupType','aggr_lkup_typ')
df_measurevals = df_measurevals.withColumnRenamed('MeasureValueNumeric','measure_val_numrc')
df_measurevals = df_measurevals.withColumnRenamed('MeasureValueString','measure_val_str')
df_measurevals = df_measurevals.withColumnRenamed('EffectiveFromDate','efftve_frm_dt')
df_measurevals = df_measurevals.withColumnRenamed('EffectiveToDate','efftve_to_dt')
df_measurevals = df_measurevals.withColumnRenamed('CurrentFlag','current_flg')
df_measurevals = df_measurevals.withColumnRenamed('HasDetailFlag','has_detail_flg')
df_measurevals = df_measurevals.withColumnRenamed('AuditPlanName','audit_plan_nm')
df_measurevals = df_measurevals.withColumnRenamed('MeasureOtherFlag','measure_othr_flg')
df_measurevals = df_measurevals.withColumnRenamed('MeasureOtherDescription','measure_othr_desc')
df_measurevals = df_measurevals.withColumnRenamed('ValueProvenanceDescription','val_prov_desc')
df_measurevals = df_measurevals.withColumnRenamed('CreatedDateTime','created_dt_tm')
df_measurevals = df_measurevals.withColumnRenamed('UpdatedDateTime','updated_dt_tm')
df_measurevals.write.saveAsTable("cra_placeaudit.cra_measure_values", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_measure_values")

#---Read eventdetails csv -- 
df_eventdetails_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Landing/eventdetails.csv")
df_eventdetails = df_eventdetails_raw.select(col("EventID").alias("pid"), 'EventDate', 'EventStartTime', 'EventEndTime', 'EventName', 'EventLocation','eventAddress','EventLatitude', 'EventLongitude','EventInformationSource')
df_eventdetails = df_eventdetails.withColumnRenamed('EventDate','event_dt')
df_eventdetails = df_eventdetails.withColumnRenamed('EventStartTime','event_strt_tm')
df_eventdetails = df_eventdetails.withColumnRenamed('EventEndTime','event_end_tm')
df_eventdetails = df_eventdetails.withColumnRenamed('EventName','event_nm')
df_eventdetails = df_eventdetails.withColumnRenamed('EventLocation','event_loc')
df_eventdetails = df_eventdetails.withColumnRenamed('eventAddress','event_addr')
df_eventdetails = df_eventdetails.withColumnRenamed('EventLatitude','event_lat')
df_eventdetails = df_eventdetails.withColumnRenamed('EventLongitude','event_lon')
df_eventdetails = df_eventdetails.withColumnRenamed('EventInformationSource','event_info_src')
df_eventdetails.write.saveAsTable("cra_placeaudit.cra_event_details", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_event_details")

#---Read auditplans csv -- 
df_auditplan_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Landing/auditplandetails.csv")
df_auditplan = df_auditplan_raw.select(col("AuditPlanID").alias("pid"),'AuditPlanName', 'AuditPlanDescription', 'AuditPlanReportDate', 'AuditConductedBySupplierName', 'AuditPlanCost', 'CommissionedBy', 'RelatedToPrecinctName', 'CommissionedForProjectName')
df_auditplan = df_auditplan.withColumnRenamed('AuditPlanName','audit_plan_nm')
df_auditplan = df_auditplan.withColumnRenamed('AuditPlanDescription','audit_plan_descr')
df_auditplan = df_auditplan.withColumnRenamed('AuditPlanReportDate','audit_plan_rprt_dt')
df_auditplan = df_auditplan.withColumnRenamed('AuditConductedBySupplierName','audit_cndt_supplr_nm')
df_auditplan = df_auditplan.withColumnRenamed('AuditPlanCost','audit_plan_cst')
df_auditplan = df_auditplan.withColumnRenamed('CommissionedBy','commissioned_by')
df_auditplan = df_auditplan.withColumnRenamed('RelatedToPrecinctName','reltd_precinct_nm')
df_auditplan = df_auditplan.withColumnRenamed('CommissionedForProjectName','commsd_fr_prjt_nm')
df_auditplan.write.saveAsTable("cra_placeaudit.cra_audit_plan", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_audit_plan")


#---Read footfallcount_hourly csv -- 
df_footfallcount_hourly_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Landing/footfallcount_hourly.csv")
df_footfallcount_hourly = df_footfallcount_hourly_raw.select(col("RowID").alias("pid"),'ReportingDate','TimeOfDay', 'DayNightName', 'ReportingLocation','MeasureName','NumberPerson','SiteName', 'ModeMovement', 'WeatherType', 'Gender','AgeGroup', 'Comments')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('ReportingDate','reporting_dt')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('TimeOfDay','time_of_dy')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('DayNightName','daynight_tm')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('ReportingLocation','reprtng_loc')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('MeasureName','measure_nm')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('NumberPerson','number_person')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('SiteName','site_nm')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('ModeMovement','mode_mvmt')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('WeatherType','weather_typ')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('Gender','gender')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('AgeGroup','age_grp')
df_footfallcount_hourly = df_footfallcount_hourly.withColumnRenamed('Comments','comments')
df_footfallcount_hourly.write.saveAsTable("cra_placeaudit.cra_footfall_count_hourly", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_footfall_count_hourly")