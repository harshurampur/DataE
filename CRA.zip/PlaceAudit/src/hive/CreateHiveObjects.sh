hive -e '
CREATE DATABASE IF NOT EXISTS cra_placeaudit;

USE cra_placeaudit;
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_measure_values(
    pid INT,
	measure_nm STRING,
    precinct_nm STRING,
	reporting_prd STRING,
	format_lkup_typ STRING,
	aggr_lkup_typ STRING,
	measure_val_numrc INT,
    measure_val_str STRING,
    efftve_frm_dt STRING,
    efftve_to_dt STRING,
    current_flg STRING,
    has_detail_flg STRING,
    audit_plan_nm STRING,
    measure_othr_flg STRING,
    measure_othr_desc STRING,
    val_prov_desc STRING,
    created_dt_tm STRING,
    updated_dt_tm STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_measure_values/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_event_details(
	pid INT,
	event_dt STRING,
	event_strt_tm STRING,
	event_end_tm STRING,
    event_nm STRING,
    event_loc STRING,
    event_addr STRING,
    event_lat DECIMAL (9,6),
    event_lon DECIMAL (9,6),
    event_info_src STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_event_details/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_audit_plan(
	pid INT,
	audit_plan_nm STRING,
	audit_plan_descr STRING,
    audit_plan_rprt_dt STRING,
    audit_cndt_supplr_nm STRING,
    audit_plan_cst INT,
	commissioned_by STRING,
    reltd_precinct_nm STRING,
    commsd_fr_prjt_nm STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_audit_plan/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_footfall_count_hourly(
	pid INT,
	reporting_dt STRING,
	time_of_dy STRING,
	daynight_tm STRING,
    reprtng_loc STRING,
	measure_nm STRING,
	number_person INT,
    site_nm STRING,
    mode_mvmt STRING,
    weather_typ STRING,
    gender STRING,
    age_grp STRING,
    comments STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/PlaceAudit/Curated/cra_footfall_count_hourly/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
'