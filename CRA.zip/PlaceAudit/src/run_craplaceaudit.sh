#!/bin/bash
log_dir=$1
currentDateTime=$(date)
# strCurrentDateTime=$(date -d "$currentDateTime" +'%Y-%m-%d %H:%M:%S')
log_file="$log_dir/CRA_PlaceAudit_$(date -d "$currentDateTime" +'%Y%m%d%H%M%S').log"

export PATH=$PATH:/opt/miniconda3/bin/;
export HTTP_PROXY={{ proxy }};
export HTTPS_PROXY={{ proxy }};
echo "Running CRA PlaceAudit" >> "$log_file"

echo "Start Landing" >> "$log_file"
source /opt/miniconda3/bin/activate /home/mapr/envs/{{ conda_env }};
python /tmp/CRA/PlaceAudit/convert_excel_to_csv.py >> "$log_file"
source /opt/miniconda3/bin/deactivate
echo "Landing Completed" >> "$log_file"

Landing_Path="{{ landing_path }}"
isEmpty=$(hadoop fs -ls  $Landing_Path*.csv -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Running pyspark" >> "$log_file"
    /opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/PlaceAudit/pyspark/placeaudit_curate.py 2>&1>> "$log_file"
else
    echo "Not found." >> "$log_file"
fi

echo "Job completed" >> "$log_file"