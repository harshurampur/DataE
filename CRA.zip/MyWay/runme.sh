#!/bin/bash
target_environment=$1
project_name=$2
sub_folder=$3
log_folder="$project_name"_log
mkdir -p ~/"$log_folder"

cd ~/$project_name/$sub_folder
echo "Start generating $sub_folder CSVs to  $target_environment"
nohup ansible-playbook --inventory ~/sdld/inventory/$target_environment runme.yml -e "sshuser=actadmin" -e "product_dir=$project_name" -e "sub_project=$sub_folder" --vault-password-file=~/.av 2>&1 | tee ~/"$log_folder"/"$sub_folder"_run_me-`date +%Y-%m-%d-%H:%M:%S`.out &