import requests
import csv

# query only 2020 data
myway_url = "{{ mywayurl }}"
path_for_CSV = "{{ hadoop_path }}"

http_proxy  = "{{ proxy }}"
https_proxy = "{{ proxy }}"

proxyDict = { 
              "http"  : http_proxy, 
              "https" : https_proxy
            }

def get_requests(url):
    response = requests.get(url, proxies=proxyDict)
    if response.status_code != 200:
        # This means something went wrong.
        raise ApiError('Bad Get Request {}'.format(response.status_code))
    print("Successfull Connection!")
    return response.json()


with open(path_for_CSV, 'w+') as out_file:
    ds = get_requests(myway_url)
    #out_file.write(ds.text)
    csv_write= csv.writer(out_file, delimiter=',')
    csv_write.writerow(["fiscal_week", "myway", "paper_ticket", "total"])
    for elem in ds:
        csv_write.writerow([elem["fiscal_week"], elem["myway_1"], elem["paper_ticket_1"], elem["total"]])
