#!/bin/bash

FILE="{{ hadoop_path }}"

export PATH=$PATH:/opt/miniconda3/bin/;

echo "Running Python script"

if [[ -f "$FILE" ]]; then
    echo "$FILE exist"
    hadoop fs -rm "$FILE"
fi

python /home/mapr/CRA/MyWay/get_src_data.py 2>&1 | tee "{{ log_dir }}/run_log-`date +%Y-%m-%d-%H:%M:%S`.txt"