CREATE VIEW IF NOT EXISTS CRA.PlaceSuccess.View_CRAEvents_historic AS (
	SELECT
		`_id`, 
        `event_nm`, 
        `event_size`, 
        `event_date_pk`, 
        `event_location`, 
        `event_street`, 
        `event_suburb`, 
        `event_city`, 
        `event_lat`, 
        `event_long`, 
        `ACL_flag`, 
        `free_flag`, 
        `market_flag`, 
        `pid`
	FROM `EventsACT`.`Curated`.`cra_events_historic`
)