#! /usr/bin/env python

import csv
import xlrd
from glob import glob
import pandas as pd

path_for_csv = "{{ historic_path }}"

excel_path = "{{ source_path }}"

'''This python script is to extract each sheet in an Excel workbook as a new csv file'''


def ExceltoCSV(excel_path, csv_file_base_path):
    files=glob(excel_path + "/*.xlsx")
    for excel_file in files:
        workbook = pd.ExcelFile(excel_file)
        for sheet_name in workbook.sheet_names:
            print('processing - ' + sheet_name)
            if sheet_name == "README":
                continue
            worksheet_df = workbook.parse(sheet_name)
            csv_file_full_path = csv_file_base_path + sheet_name.lower().replace(" - ", "_").replace(" ","").replace("&","") + '.csv'
            worksheet_df.to_csv(csv_file_full_path, index=False)
            print(sheet_name + ' has been saved at - ' + csv_file_full_path)
    return


ExceltoCSV(excel_path, path_for_csv)
