hive -e '
CREATE DATABASE IF NOT EXISTS events_landing;

USE events_landing;
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_events_historic(
    pid INT,
	event_pk STRING,
    event_nm STRING,
	event_location STRING,
	event_suburb STRING,
	event_street STRING,
	event_status INT,
    event_start_dt STRING,
    event_end_dt STRING,
    event_size STRING,
    event_date_pk STRING,
    event_start_tm STRING,
    event_end_time STRING,
    event_details STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_events_historic/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");

CREATE EXTERNAL TABLE IF NOT EXISTS cra_events_api(
    pid INT,
	event_pk STRING,
    event_prod_id STRING,
    event_nm STRING,
	event_location STRING,
	event_suburb STRING,
	event_street STRING,
	event_status INT,
    event_start_dt STRING,
    event_end_dt STRING,
    event_size STRING,
    event_date_pk STRING,
    event_start_tm STRING,
    event_end_time STRING,
    multi_flag STRING,
    free_flag INT,
    event_lat DECIMAL (9,6),
    event_long DECIMAL (9,6),
    event_own_org_nm STRING,
    event_own_org_num STRING,
    event_frequency STRING,
    event_details STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_events_api/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
'