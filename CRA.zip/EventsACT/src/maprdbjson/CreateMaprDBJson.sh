DatabasePaths="/Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_api_all /Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_api_curated /Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_historic"
for DatabasePath in $DatabasePaths
do
    ExistingFlag=$(maprcli table info -path "$DatabasePath" | grep -o "does not exist")
    ObjectAction="edit"
    ObjectType=""
    ObjectTypeValue=""
    ColumnFamilies="default"
    if [ "$ExistingFlag" == "does not exist" ]
    then
        ObjectAction="create"
        ObjectType="-tabletype"
        ObjectTypeValue="json"
    fi
    maprcli table "$ObjectAction" -path "$DatabasePath" "$ObjectType" "$ObjectTypeValue" \
    -defaultreadperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_read_permission }}" \
    -defaultwriteperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_write_permission }}" \
    -defaulttraverseperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -adminaccessperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -createrenamefamilyperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -bulkloadperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -indexperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -packperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -deletefamilyperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -replperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -splitmergeperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -defaultcompressionperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
    -defaultmemoryperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}"

    if [ "$ExistingFlag" != "does not exist" ]
    then
        for cf in $ColumnFamilies
        do
            maprcli table cf "$ObjectAction" -path "$DatabasePath" -cfname "$cf" \
            -compressionperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
            -memoryperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
            -readperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_read_permission }}" \
            -traverseperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_add_object_permission }}" \
            -writeperm "{{ CMTEDD.EconomicDevelopment_EventsACT_Curated_volume_write_permission }}"
        done
    fi
done