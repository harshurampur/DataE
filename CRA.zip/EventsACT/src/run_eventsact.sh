#!/bin/bash
log_dir=$1
currentDateTime=$(date)
# strCurrentDateTime=$(date -d "$currentDateTime" +'%Y-%m-%d %H:%M:%S')
log_file="$log_dir/CRA_EventsACT_$(date -d "$currentDateTime" +'%Y%m%d%H%M%S').log"

export PATH=$PATH:/opt/miniconda3/bin/;
export HTTP_PROXY={{ proxy }};
export HTTPS_PROXY={{ proxy }};
echo "Running CRA EventsACT" >> "$log_file"

echo "Reading EventsACT API" >> "$log_file"

echo "Start Sourcing jsons" >> "$log_file"

python /tmp/CRA/EventsACT/get_src_data.py >> "$log_file"

echo "Source jsons Completed" >> "$log_file"

echo "Start Landing" >> "$log_file"
source /opt/miniconda3/bin/activate /home/mapr/envs/{{ conda_env }};
python /tmp/CRA/EventsACT/convert_excel_to_csv.py >> "$log_file"
source /opt/miniconda3/bin/deactivate
echo "Landing Completed" >> "$log_file"

Source_Path_historic="{{ source_path }}eventhistoric/"
isEmpty=$(hadoop fs -ls  $Source_Path_historic*.csv -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Running pyspark" >> "$log_file"
    /opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/EventsACT/pyspark/eventsact_landing.py 2>&1>> "$log_file"
else
    echo "Not found." >> "$log_file"
fi


sleep 5s

echo "Running Curation Historic" >> "$log_file"
/opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/EventsACT/pyspark/eventsact_curated.py 2>&1>> "$log_file"
echo "Curation Historic Completed" >> "$log_file"


Source_Path="{{ source_path }}eventapi/"
isjsonEmpty=$(hadoop fs -ls  $Source_Path*.json -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isjsonEmpty -ne 0 ]
then
    echo "Running pyspark jsons" >> "$log_file"
    /opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/EventsACT/pyspark/eventapi_landing.py 2>&1>> "$log_file"
else
    echo "Not found jsons." >> "$log_file"
fi

sleep 5s

echo "Running Curation" >> "$log_file"
/opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/EventsACT/pyspark/eventapi_curated.py 2>&1>> "$log_file"
echo "Curation Completed" >> "$log_file"

echo "Job completed" >> "$log_file"