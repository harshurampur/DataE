from pyspark.sql import SparkSession
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.functions import col, collect_list, concat_ws, sha2
from pyspark.sql.functions import regexp_replace, regexp_extract, expr, when, lit
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.functions import udf
from pyspark.sql.types import ArrayType, StringType
import pyspark.sql.functions as F
import os, subprocess
import re
import pyspark.sql.functions as psf


def blank_as_na(x):
    return when((col(x) != "") & (col(x) != "null") , col(x)).otherwise('Not Available')

def check_free_flag(x):
    return when((col(x) =='1') , "Yes").when((col(x) =='') , "Not Available").otherwise("No")

def is_blank_then_null(x):
    return when((col(x) != "") , col(x)).otherwise(None)


sparksession = (SparkSession
                .builder
                .appName("CRA-eventsact-curation")
                .enableHiveSupport()
                .getOrCreate())


schema = StructType([
    StructField("event_prod_id", StringType(), True),
    StructField("event_nm", StringType(), True),
    StructField("event_location", StringType(), True),
    StructField("event_street", StringType(), True),
    StructField("event_suburb", StringType(), True),
    StructField("event_city", StringType(), True),
    StructField("event_state", StringType(), True),
    StructField("event_country", StringType(), True),
    StructField("event_lat", DecimalType(9,6), True),
    StructField("event_long", DecimalType(9,6), True),
    StructField("free_flag", StringType(), True),
    StructField("event_start_dt", DateType(), True),
    StructField("event_end_dt", DateType(), True),
    StructField("event_date_pk", DateType(), True),
    StructField("event_start_tm", StringType(), True),
    StructField("event_end_tm", StringType(), True),
    StructField("event_descrptn", StringType(), True),
    StructField("event_category", StringType(), True),
    StructField("event_own_org_nm", StringType(), True),
    StructField("event_own_org_num", StringType(), True),
    StructField("event_org_abn", StringType(), True),
    StructField("event_org_email", StringType(), True),
    StructField("event_org_contact", StringType(), True),
    StructField("event_org_url", StringType(), True),
    StructField("event_frequency", StringType(), True),
    StructField("event_size", StringType(), True),
    StructField("ACL_flag", StringType(), True),
    StructField("market_flag", StringType(), True)
])

# Read events landing 
df_landing_event = sparksession.sql("SELECT unique_pid as pid,event_prod_id, event_nm, event_location, event_street, event_suburb, event_city, event_state, event_country, event_lat, event_long, free_flag,event_start_dt,event_end_dt,event_date_pk, event_start_tm, event_end_tm, event_descrptn, event_category,event_own_org_nm, event_own_org_num,event_org_abn,event_org_email,event_org_contact,event_url,event_frequency,event_size  FROM events_landing.cra_events_api")
df_landing_event = df_landing_event.withColumn('event_start_dt', is_blank_then_null('event_start_dt'))
df_landing_event = df_landing_event.withColumn('event_end_dt', is_blank_then_null('event_end_dt'))
df_landing_event = df_landing_event.withColumn('event_location', blank_as_na('event_location'))
df_landing_event = df_landing_event.withColumn('event_street', blank_as_na('event_street'))
df_landing_event = df_landing_event.withColumn('event_suburb', blank_as_na('event_suburb'))
df_landing_event = df_landing_event.withColumn('event_city', blank_as_na('event_city'))
df_landing_event = df_landing_event.withColumn('event_state', lit('ACT'))
df_landing_event = df_landing_event.withColumn('event_country', lit('AU'))
df_landing_event = df_landing_event.withColumn('event_lat', df_landing_event['event_lat'].cast(DoubleType()))
df_landing_event = df_landing_event.withColumn('event_long', df_landing_event['event_long'].cast(DoubleType()))
df_landing_event = df_landing_event.withColumn('free_flag', check_free_flag('free_flag'))
df_landing_event = df_landing_event.withColumn('event_date_pk', (is_blank_then_null('event_date_pk')).cast(DateType()))
df_landing_event = df_landing_event.withColumn('event_start_dt', df_landing_event['event_start_dt'].cast(DateType()))
df_landing_event = df_landing_event.withColumn('event_end_dt', df_landing_event['event_end_dt'].cast(DateType()))
df_landing_event = df_landing_event.withColumn('event_start_tm', blank_as_na('event_start_tm'))
df_landing_event = df_landing_event.withColumn('event_end_tm', blank_as_na('event_end_tm'))
df_landing_event = df_landing_event.withColumn('event_own_org_nm', blank_as_na('event_own_org_nm'))
df_landing_event = df_landing_event.withColumn('event_own_org_num', blank_as_na('event_own_org_num'))
df_landing_event = df_landing_event.withColumn('event_org_abn', blank_as_na('event_org_abn'))
df_landing_event = df_landing_event.withColumn('event_org_email', blank_as_na('event_org_email'))
df_landing_event = df_landing_event.withColumn('event_org_contact', blank_as_na('event_org_contact'))
df_landing_event = df_landing_event.withColumn('event_url', blank_as_na('event_url'))
df_landing_event = df_landing_event.withColumn('event_frequency', blank_as_na('event_frequency'))
df_landing_event = df_landing_event.withColumn('event_size', blank_as_na('event_size'))
df_landing_event = df_landing_event.withColumn('ACL_flag', lit('No'))
df_landing_event = df_landing_event.withColumn('market_flag', lit('No'))
df_landing_event = df_landing_event.select('pid','event_prod_id', 'event_nm', 'event_location', 'event_street', 'event_suburb', 'event_city', 'event_state', 'event_country', 'event_lat', 'event_long', 'free_flag','event_start_dt','event_end_dt','event_date_pk', 'event_start_tm', 'event_end_tm', 'event_descrptn', 'event_category','event_own_org_nm', 'event_own_org_num','event_org_abn','event_org_email','event_org_contact','event_url','event_frequency','event_size','ACL_flag', 'market_flag')


df_landing_market = sparksession.sql("SELECT unique_pid as pid,event_prod_id, event_nm, event_location, event_street, event_suburb, event_city, event_state, event_country, event_lat, event_long, free_flag,event_start_dt,event_end_dt,event_date_pk, event_start_tm, event_end_tm, event_descrptn, event_category,event_own_org_nm, event_own_org_num,event_org_abn,event_org_email,event_org_contact,event_url,event_frequency,event_size  FROM events_landing.cra_market_api")
df_landing_market = df_landing_market.withColumn('event_start_dt', (is_blank_then_null('event_start_dt')).cast(DateType()))
df_landing_market = df_landing_market.withColumn('event_end_dt', (is_blank_then_null('event_end_dt')).cast(DateType()))
df_landing_market = df_landing_market.withColumn('event_location', blank_as_na('event_location'))
df_landing_market = df_landing_market.withColumn('event_street', blank_as_na('event_street'))
df_landing_market = df_landing_market.withColumn('event_suburb', blank_as_na('event_suburb'))
df_landing_market = df_landing_market.withColumn('event_city', blank_as_na('event_city'))
df_landing_market = df_landing_market.withColumn('event_state', lit('ACT'))
df_landing_market = df_landing_market.withColumn('event_country', lit('AU'))
df_landing_market = df_landing_market.withColumn('event_lat', df_landing_market['event_lat'].cast(DoubleType()))
df_landing_market = df_landing_market.withColumn('event_long', df_landing_market['event_long'].cast(DoubleType()))
df_landing_market = df_landing_market.withColumn('free_flag', check_free_flag('free_flag'))
df_landing_market = df_landing_market.withColumn('event_date_pk', (is_blank_then_null('event_date_pk')).cast(DateType()))
df_landing_market = df_landing_market.withColumn('event_start_tm', blank_as_na('event_start_tm'))
df_landing_market = df_landing_market.withColumn('event_end_tm', blank_as_na('event_end_tm'))
df_landing_market = df_landing_market.withColumn('event_own_org_nm', blank_as_na('event_own_org_nm'))
df_landing_market = df_landing_market.withColumn('event_own_org_num', blank_as_na('event_own_org_num'))
df_landing_market = df_landing_market.withColumn('event_org_abn', blank_as_na('event_org_abn'))
df_landing_market = df_landing_market.withColumn('event_org_email', blank_as_na('event_org_email'))
df_landing_market = df_landing_market.withColumn('event_org_contact', blank_as_na('event_org_contact'))
df_landing_market = df_landing_market.withColumn('event_url', blank_as_na('event_url'))
df_landing_market = df_landing_market.withColumn('event_frequency', blank_as_na('event_frequency'))
df_landing_market = df_landing_market.withColumn('event_size', blank_as_na('event_size'))
df_landing_market = df_landing_market.withColumn('ACL_flag', lit('No'))
df_landing_market = df_landing_market.withColumn('market_flag', lit('Yes'))
df_landing_market = df_landing_market.select('pid','event_prod_id', 'event_nm', 'event_location', 'event_street', 'event_suburb', 'event_city', 'event_state', 'event_country', 'event_lat', 'event_long', 'free_flag','event_start_dt','event_end_dt','event_date_pk', 'event_start_tm', 'event_end_tm', 'event_descrptn', 'event_category','event_own_org_nm', 'event_own_org_num','event_org_abn','event_org_email','event_org_contact','event_url','event_frequency','event_size','ACL_flag', 'market_flag')
df_concat_e_m = df_landing_event.union(df_landing_market)


df_landing_artculture = sparksession.sql("SELECT unique_pid as pid,event_prod_id, event_nm, event_location, event_street, event_suburb, event_city, event_state, event_country, event_lat, event_long, free_flag,event_start_dt,event_end_dt,event_date_pk, event_start_tm, event_end_tm, event_descrptn, event_category,event_own_org_nm, event_own_org_num,event_org_abn,event_org_email,event_org_contact,event_url,event_frequency,event_size  FROM events_landing.cra_artculture_api")
df_landing_artculture = df_landing_artculture.withColumn('event_start_dt', (is_blank_then_null('event_start_dt')).cast(DateType()))
df_landing_artculture = df_landing_artculture.withColumn('event_end_dt', (is_blank_then_null('event_end_dt')).cast(DateType()))
df_landing_artculture = df_landing_artculture.withColumn('event_location', blank_as_na('event_location'))
df_landing_artculture = df_landing_artculture.withColumn('event_street', blank_as_na('event_street'))
df_landing_artculture = df_landing_artculture.withColumn('event_suburb', blank_as_na('event_suburb'))
df_landing_artculture = df_landing_artculture.withColumn('event_city', blank_as_na('event_city'))
df_landing_artculture = df_landing_artculture.withColumn('event_state', lit('ACT'))
df_landing_artculture = df_landing_artculture.withColumn('event_country', lit('AU'))
df_landing_artculture = df_landing_artculture.withColumn('event_lat', df_landing_artculture['event_lat'].cast(DoubleType()))
df_landing_artculture = df_landing_artculture.withColumn('event_long', df_landing_artculture['event_long'].cast(DoubleType()))
df_landing_artculture = df_landing_artculture.withColumn('free_flag', check_free_flag('free_flag'))
df_landing_artculture = df_landing_artculture.withColumn('event_date_pk', (is_blank_then_null('event_date_pk')).cast(DateType()))
df_landing_artculture = df_landing_artculture.withColumn('event_start_tm', blank_as_na('event_start_tm'))
df_landing_artculture = df_landing_artculture.withColumn('event_end_tm', blank_as_na('event_end_tm'))
df_landing_artculture = df_landing_artculture.withColumn('event_own_org_nm', blank_as_na('event_own_org_nm'))
df_landing_artculture = df_landing_artculture.withColumn('event_own_org_num', blank_as_na('event_own_org_num'))
df_landing_artculture = df_landing_artculture.withColumn('event_org_abn', blank_as_na('event_org_abn'))
df_landing_artculture = df_landing_artculture.withColumn('event_org_email', blank_as_na('event_org_email'))
df_landing_artculture = df_landing_artculture.withColumn('event_org_contact', blank_as_na('event_org_contact'))
df_landing_artculture = df_landing_artculture.withColumn('event_url', blank_as_na('event_url'))
df_landing_artculture = df_landing_artculture.withColumn('event_frequency', blank_as_na('event_frequency'))
df_landing_artculture = df_landing_artculture.withColumn('event_size', blank_as_na('event_size'))
df_landing_artculture = df_landing_artculture.withColumn('ACL_flag', lit('Yes'))
df_landing_artculture = df_landing_artculture.withColumn('market_flag', lit('No'))
df_landing_artculture = df_landing_artculture.select('pid','event_prod_id', 'event_nm', 'event_location', 'event_street', 'event_suburb', 'event_city', 'event_state', 'event_country', 'event_lat', 'event_long', 'free_flag','event_start_dt','event_end_dt','event_date_pk', 'event_start_tm', 'event_end_tm', 'event_descrptn', 'event_category','event_own_org_nm', 'event_own_org_num','event_org_abn','event_org_email','event_org_contact','event_url','event_frequency','event_size','ACL_flag', 'market_flag')

df_concat_em_ac = df_concat_e_m.union(df_landing_artculture)

df_landing_leisure = sparksession.sql("SELECT unique_pid as pid,event_prod_id, event_nm, event_location, event_street, event_suburb, event_city, event_state, event_country, event_lat, event_long, free_flag, event_descrptn, event_category,event_own_org_nm, event_own_org_num,event_org_abn,event_org_email,event_org_contact,event_url,event_size  FROM events_landing.cra_leisure_api")
df_landing_leisure = df_landing_leisure.withColumn('event_start_dt', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_end_dt', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_location', blank_as_na('event_location'))
df_landing_leisure = df_landing_leisure.withColumn('event_street', blank_as_na('event_street'))
df_landing_leisure = df_landing_leisure.withColumn('event_suburb', blank_as_na('event_suburb'))
df_landing_leisure = df_landing_leisure.withColumn('event_city', blank_as_na('event_city'))
df_landing_leisure = df_landing_leisure.withColumn('event_state', lit('ACT'))
df_landing_leisure = df_landing_leisure.withColumn('event_country', lit('AU'))
df_landing_leisure = df_landing_leisure.withColumn('event_lat', df_landing_leisure['event_lat'].cast(DoubleType()))
df_landing_leisure = df_landing_leisure.withColumn('event_long', df_landing_leisure['event_long'].cast(DoubleType()))
df_landing_leisure = df_landing_leisure.withColumn('free_flag', check_free_flag('free_flag'))
df_landing_leisure = df_landing_leisure.withColumn('event_date_pk', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_start_tm', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_end_tm', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_own_org_nm', blank_as_na('event_own_org_nm'))
df_landing_leisure = df_landing_leisure.withColumn('event_own_org_num', blank_as_na('event_own_org_num'))
df_landing_leisure = df_landing_leisure.withColumn('event_org_abn', blank_as_na('event_org_abn'))
df_landing_leisure = df_landing_leisure.withColumn('event_org_email', blank_as_na('event_org_email'))
df_landing_leisure = df_landing_leisure.withColumn('event_org_contact', blank_as_na('event_org_contact'))
df_landing_leisure = df_landing_leisure.withColumn('event_url', blank_as_na('event_url'))
df_landing_leisure = df_landing_leisure.withColumn('event_frequency', lit(None))
df_landing_leisure = df_landing_leisure.withColumn('event_size', blank_as_na('event_size'))
df_landing_leisure = df_landing_leisure.withColumn('ACL_flag', lit('Yes'))
df_landing_leisure = df_landing_leisure.withColumn('market_flag', lit('No'))
df_landing_leisure = df_landing_leisure.select('pid','event_prod_id', 'event_nm', 'event_location', 'event_street', 'event_suburb', 'event_city', 'event_state', 'event_country', 'event_lat', 'event_long', 'free_flag','event_start_dt','event_end_dt','event_date_pk', 'event_start_tm', 'event_end_tm', 'event_descrptn', 'event_category','event_own_org_nm', 'event_own_org_num','event_org_abn','event_org_email','event_org_contact','event_url','event_frequency','event_size','ACL_flag', 'market_flag')


df_concat_event_all = df_concat_em_ac.union(df_landing_leisure)

sparksession.saveToMapRDB(df_concat_event_all, "/Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_api_all", id_field_path = "pid", create_table = False, bulk_insert = False)

df_curation_event = df_concat_event_all.filter(df_concat_event_all.event_date_pk !="null")
df_curation_event = df_curation_event.withColumn("ingestion_date",F.current_date())

sparksession.saveToMapRDB(df_curation_event, "/Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_api_curated", id_field_path = "pid", create_table = False, bulk_insert = False)