from pyspark.sql import SparkSession
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.functions import col, collect_list, concat_ws, sha2
from pyspark.sql.functions import regexp_replace, regexp_extract, expr, when, lit
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.functions import udf
from pyspark.sql.types import ArrayType, StringType
import pyspark.sql.functions as F
import os, subprocess
import re
import pyspark.sql.functions as psf

def archiveSourceFile():
    archive_file_command = "hadoop fs -cp -f /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/*/*/*.json /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -cp -f /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/*/*.json /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -rm /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/*/*/*.json"
    os.system(archive_file_command)
    archive_rmfile_command = "hadoop fs -rm /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/Archive/product*.json"
    os.system(archive_rmfile_command)
    print("Remove and Archive Source Files")
    return


def get_subcols(df, col):
    if col in df.columns:
        subschema = [s["type"]["elementType"]["fields"] for s in df.schema.jsonValue()["fields"] if s["name"] == col][0]
        return  [s["name"] for s in subschema]
    else:
        return None


def flatten_df(df):
    non_nested_cols = [c[0] for c in df.dtypes if not re.match("array<struct|struct", c[1])]
    nested_cols = [c[0] for c in df.dtypes if re.match("array<struct|struct", c[1])]
    return df.select(non_nested_cols + [psf.col(c1 + "." + c2) for c1 in nested_cols for c2 in get_subcols(df, c1)])


def blank_as_null(x):
    return when((col(x) != "") & (col(x) != "null") , col(x)).otherwise('Not Available')


def get_email(x,y):
    return (when((col(x).getItem(0) == "Email Enquiries") ,col(y).getItem(0)).otherwise("")) 
def get_phone(x,y):
    return when((col(x).getItem(1) == "Primary Phone") ,col(y).getItem(1)).when((col(x).getItem(0) == "Primary Phone") ,col(y).getItem(0)).otherwise("")
def get_url(x,y):
    return (when(((col(x).getItem(2) == "URL Enquiries") | (col(x).getItem(2) == "Booking URL"))  ,col(y).getItem(2)).when(((col(x).getItem(1) == "URL Enquiries") | (col(x).getItem(1) == "Booking URL")) ,col(y).getItem(1)).otherwise(""))


sparksession = (SparkSession
                .builder
                .appName("CRA-eventsact-api")
                .enableHiveSupport()
                .getOrCreate())

# Read events json
# Read sub products jsons 
df_events_raw = sparksession.read.option("multiline","true").json("/Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventapi/events/product*.json")
df_events = df_events_raw.select('productId','productName','frequencyStartDate','frequencyEndDate','freeEntryFlag', 'nextOccurrence','cityName', 'suburbName','stateName','areaName', 'countryName', 'productShortDescription','productCategoryDescription', 'owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','attributeIdFrequency','totalCapacity')

df_address = df_events_raw.select('addresses',col('productId').alias('pid'))
df_time = df_events_raw.select('eventFrequency',col('productId').alias('pida'))
df_comm = df_events_raw.select('communication',col('productId').alias('pidc'))

df_address = flatten_df(df_address)
df_time = flatten_df(df_time)
df_comm = flatten_df(df_comm)

df_address = df_address.selectExpr( 'pid','addressLine1[0] as address1', 'geocodeGdaLatitude[0] as geolatitude','geocodeGdaLongitude[0] as geolongitude')
df_time = df_time.selectExpr('pida','frequencyStartTime[0] as checkInTime','frequencyEndTime[0] as checkOutTime')

#----------- join address and time---------------------
df_combined_alpha = df_address.join(df_time, df_address.pid == df_time.pida)
df_combined_alpha = df_combined_alpha.drop(df_combined_alpha.pida)

df_comm_new = df_comm.select('pidc','attributeIdCommunicationDescription','communicationDetail')
df_comm_new = df_comm_new.withColumn("email",get_email("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_new = df_comm_new.withColumn("contact",get_phone("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_new = df_comm_new.withColumn("url",get_url("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_new = df_comm_new.drop(df_comm_new.attributeIdCommunicationDescription)
df_comm_new = df_comm_new.drop(df_comm_new.communicationDetail)
#-----Join communication with address and time
df_combined = df_combined_alpha.join(df_comm_new, df_combined_alpha.pid == df_comm_new.pidc)
df_combined = df_combined.drop(df_combined.pidc)

#--- Join events with all combined above----
df_events_new=df_events.join(df_combined,df_events.productId == df_combined.pid)
df_events_new=df_events_new.drop(df_events_new.pid)

df_events_data = df_events_new.select('productId','productName','areaName','address1','suburbName','cityName','stateName','countryName','geolatitude','geolongitude','freeEntryFlag','frequencyStartDate','frequencyEndDate','nextOccurrence', 'checkInTime','checkOutTime', 'productShortDescription','productCategoryDescription','owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','email','contact', 'url','attributeIdFrequency','totalCapacity')
#---- Add unique identifier for all columns hashing through sha2 and adding in column :unique_pid"--------------
df_events_data = df_events_data.withColumn("unique_pid", sha2(concat_ws("||", *df_events_data.columns), 512))
#------------------------------------------------------------------------------------------------------------------
df_events_data = df_events_data.withColumnRenamed('productId','event_prod_id')
df_events_data = df_events_data.withColumnRenamed('productName','event_nm')
df_events_data = df_events_data.withColumnRenamed('areaName','event_location')
df_events_data = df_events_data.withColumnRenamed('address1','event_street')
df_events_data = df_events_data.withColumnRenamed('suburbName','event_suburb')
df_events_data = df_events_data.withColumnRenamed('cityName','event_city')
df_events_data = df_events_data.withColumnRenamed('stateName','event_state')
df_events_data = df_events_data.withColumnRenamed('countryName','event_country')
df_events_data = df_events_data.withColumnRenamed('geolatitude','event_lat')
df_events_data = df_events_data.withColumnRenamed('geolongitude','event_long')
df_events_data = df_events_data.withColumnRenamed('freeEntryFlag','free_flag')
df_events_data = df_events_data.withColumnRenamed('frequencyStartDate','event_start_dt')
df_events_data = df_events_data.withColumnRenamed('frequencyEndDate','event_end_dt')
df_events_data = df_events_data.withColumnRenamed('nextOccurrence','event_date_pk')
df_events_data = df_events_data.withColumnRenamed('checkInTime','event_start_tm')
df_events_data = df_events_data.withColumnRenamed('checkOutTime','event_end_tm')
df_events_data = df_events_data.withColumnRenamed('productShortDescription','event_descrptn')
df_events_data = df_events_data.withColumnRenamed('productCategoryDescription','event_category')
df_events_data = df_events_data.withColumnRenamed('owningOrganisationName','event_own_org_nm')
df_events_data = df_events_data.withColumnRenamed('owningOrganisationNumber','event_own_org_num')
df_events_data = df_events_data.withColumnRenamed('australianBusinessNumber','event_org_abn')
df_events_data = df_events_data.withColumnRenamed('email','event_org_email')
df_events_data = df_events_data.withColumnRenamed('contact','event_org_contact')
df_events_data = df_events_data.withColumnRenamed('url','event_url')
df_events_data = df_events_data.withColumnRenamed('attributeIdFrequency','event_frequency')
df_events_data = df_events_data.withColumnRenamed('totalCapacity','event_size')
df_events_data.write.saveAsTable("events_landing.cra_events_api", format="parquet", mode="overwrite", path="/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_events_api")
#----------------------------------------------------------------------------------------------------------
# Read Market json 
# Read sub products jsons 
df_market_raw = sparksession.read.option("multiline","true").json("/Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventapi/markets/product*.json")
df_market = df_market_raw.select('productId','productName','frequencyStartDate','frequencyEndDate','freeEntryFlag', 'nextOccurrence','cityName', 'suburbName','stateName','areaName', 'countryName', 'productShortDescription','productCategoryDescription', 'owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','attributeIdFrequency','totalCapacity')

df_address_m = df_market_raw.select('addresses',col('productId').alias('pid'))
df_time_m = df_market_raw.select('eventFrequency',col('productId').alias('pida'))
df_comm_m = df_market_raw.select('communication',col('productId').alias('pidc'))

df_addm_new = flatten_df(df_address_m)
df_time_m = flatten_df(df_time_m)
df_comm_m = flatten_df(df_comm_m)

df_addm_new = df_addm_new.selectExpr( 'pid','addressLine1[0] as address1', 'geocodeGdaLatitude[0] as geolatitude','geocodeGdaLongitude[0] as geolongitude')
df_time_m = df_time_m.selectExpr('pida','frequencyStartTime[0] as checkInTime','frequencyEndTime[0] as checkOutTime')

#----------- join address and time---------------------
df_combined_alpha_m = df_addm_new.join(df_time_m, df_addm_new.pid == df_time_m.pida)
df_combined_alpha_m = df_combined_alpha_m.drop(df_combined_alpha_m.pida)

df_comm_m_new = df_comm_m.select('pidc','attributeIdCommunicationDescription','communicationDetail')
df_comm_m_new = df_comm_m_new.withColumn("email",get_email("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_m_new = df_comm_m_new.withColumn("contact",get_phone("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_m_new = df_comm_m_new.withColumn("url",get_url("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_m_new = df_comm_m_new.drop(df_comm_m_new.attributeIdCommunicationDescription)
df_comm_m_new = df_comm_m_new.drop(df_comm_m_new.communicationDetail)
#-----Join communication with address and time
df_combined_m = df_combined_alpha_m.join(df_comm_m_new, df_combined_alpha_m.pid == df_comm_m_new.pidc)
df_combined_m = df_combined_m.drop(df_combined_m.pidc)

#--- Join markets with all combined above----
df_market_new = df_market.join(df_combined_m,df_market.productId == df_combined_m.pid)
df_market_new = df_market_new.drop(df_market_new.pid)
#----------------------------------------------------------------------------------------------------------
df_market_data = df_market_new.select('productId','productName','areaName','address1','suburbName','cityName','stateName','countryName','geolatitude','geolongitude','freeEntryFlag','frequencyStartDate','frequencyEndDate','nextOccurrence', 'checkInTime','checkOutTime', 'productShortDescription','productCategoryDescription','owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','email','contact', 'url','attributeIdFrequency','totalCapacity')
#---- Add unique identifier for all columns hashing through sha2 and adding in column :unique_pid"--------------
df_market_data = df_market_data.withColumn("unique_pid", sha2(concat_ws("||", *df_market_data.columns), 512))
#------------------------------------------------------------------------------------------------------------------
df_market_data = df_market_data.withColumnRenamed('productId','event_prod_id')
df_market_data = df_market_data.withColumnRenamed('productName','event_nm')
df_market_data = df_market_data.withColumnRenamed('areaName','event_location')
df_market_data = df_market_data.withColumnRenamed('address1','event_street')
df_market_data = df_market_data.withColumnRenamed('suburbName','event_suburb')
df_market_data = df_market_data.withColumnRenamed('cityName','event_city')
df_market_data = df_market_data.withColumnRenamed('stateName','event_state')
df_market_data = df_market_data.withColumnRenamed('countryName','event_country')
df_market_data = df_market_data.withColumnRenamed('geolatitude','event_lat')
df_market_data = df_market_data.withColumnRenamed('geolongitude','event_long')
df_market_data = df_market_data.withColumnRenamed('freeEntryFlag','free_flag')
df_market_data = df_market_data.withColumnRenamed('frequencyStartDate','event_start_dt')
df_market_data = df_market_data.withColumnRenamed('frequencyEndDate','event_end_dt')
df_market_data = df_market_data.withColumnRenamed('nextOccurrence','event_date_pk')
df_market_data = df_market_data.withColumnRenamed('checkInTime','event_start_tm')
df_market_data = df_market_data.withColumnRenamed('checkOutTime','event_end_tm')
df_market_data = df_market_data.withColumnRenamed('productShortDescription','event_descrptn')
df_market_data = df_market_data.withColumnRenamed('productCategoryDescription','event_category')
df_market_data = df_market_data.withColumnRenamed('owningOrganisationName','event_own_org_nm')
df_market_data = df_market_data.withColumnRenamed('owningOrganisationNumber','event_own_org_num')
df_market_data = df_market_data.withColumnRenamed('australianBusinessNumber','event_org_abn')
df_market_data = df_market_data.withColumnRenamed('email','event_org_email')
df_market_data = df_market_data.withColumnRenamed('contact','event_org_contact')
df_market_data = df_market_data.withColumnRenamed('url','event_url')
df_market_data = df_market_data.withColumnRenamed('attributeIdFrequency','event_frequency')
df_market_data = df_market_data.withColumnRenamed('totalCapacity','event_size')
df_market_data.write.saveAsTable("events_landing.cra_market_api", format="parquet", mode="overwrite", path="/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_market_api")
#------------------------------------------------------------------------------------------------------------------

# Read artculture json 
# Read sub products jsons 
df_artculture_raw = sparksession.read.option("multiline","true").json("/Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventapi/artculture/product*.json")
df_artculture = df_artculture_raw.select('productId','productName','frequencyStartDate','frequencyEndDate','freeEntryFlag', 'nextOccurrence','cityName', 'suburbName','stateName','areaName', 'countryName', 'productShortDescription','productCategoryDescription', 'owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','attributeIdFrequency','totalCapacity')

df_address_ac = df_artculture_raw.select('addresses',col('productId').alias('pid'))
df_time_ac = df_artculture_raw.select('eventFrequency',col('productId').alias('pida'))
df_comm_ac = df_artculture_raw.select('communication',col('productId').alias('pidc'))

df_addac_new = flatten_df(df_address_ac)
df_time_ac = flatten_df(df_time_ac)
df_comm_ac = flatten_df(df_comm_ac)

df_addac_new = df_addac_new.selectExpr( 'pid','addressLine1[0] as address1', 'geocodeGdaLatitude[0] as geolatitude','geocodeGdaLongitude[0] as geolongitude')
df_time_ac = df_time_ac.selectExpr('pida','frequencyStartTime[0] as checkInTime','frequencyEndTime[0] as checkOutTime')

#----------- join address and time---------------------
df_combined_alpha_ac = df_addac_new.join(df_time_ac, df_addac_new.pid == df_time_ac.pida)
df_combined_alpha_ac = df_combined_alpha_ac.drop(df_combined_alpha_ac.pida)

df_comm_ac_new = df_comm_ac.select('pidc','attributeIdCommunicationDescription','communicationDetail')
df_comm_ac_new = df_comm_ac_new.withColumn("email",get_email("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_ac_new = df_comm_ac_new.withColumn("contact",get_phone("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_ac_new = df_comm_ac_new.withColumn("url",get_url("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_ac_new = df_comm_ac_new.drop(df_comm_ac_new.attributeIdCommunicationDescription)
df_comm_ac_new = df_comm_ac_new.drop(df_comm_ac_new.communicationDetail)
#-----Join communication with address and time
df_combined_ac = df_combined_alpha_ac.join(df_comm_ac_new, df_combined_alpha_ac.pid == df_comm_ac_new.pidc)
df_combined_ac = df_combined_ac.drop(df_combined_ac.pidc)

#--- Join arts culture with all combined above----
df_artculture_new = df_artculture.join(df_combined_ac,df_artculture.productId == df_combined_ac.pid)
df_artculture_new = df_artculture_new.drop(df_artculture_new.pid)
#----------------------------------------------------------------------------------------------------------
df_artculture_data = df_artculture_new.select('productId','productName','areaName','address1','suburbName','cityName','stateName','countryName','geolatitude','geolongitude','freeEntryFlag','frequencyStartDate','frequencyEndDate','nextOccurrence', 'checkInTime','checkOutTime', 'productShortDescription','productCategoryDescription','owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','email','contact', 'url','attributeIdFrequency','totalCapacity')
#---- Add unique identifier for all columns hashing through sha2 and adding in column :unique_pid"--------------
df_artculture_data = df_artculture_data.withColumn("unique_pid", sha2(concat_ws("||", *df_artculture_data.columns), 512))
#------------------------------------------------------------------------------------------------------------------
df_artculture_data = df_artculture_data.withColumnRenamed('productId','event_prod_id')
df_artculture_data = df_artculture_data.withColumnRenamed('productName','event_nm')
df_artculture_data = df_artculture_data.withColumnRenamed('areaName','event_location')
df_artculture_data = df_artculture_data.withColumnRenamed('address1','event_street')
df_artculture_data = df_artculture_data.withColumnRenamed('suburbName','event_suburb')
df_artculture_data = df_artculture_data.withColumnRenamed('cityName','event_city')
df_artculture_data = df_artculture_data.withColumnRenamed('stateName','event_state')
df_artculture_data = df_artculture_data.withColumnRenamed('countryName','event_country')
df_artculture_data = df_artculture_data.withColumnRenamed('geolatitude','event_lat')
df_artculture_data = df_artculture_data.withColumnRenamed('geolongitude','event_long')
df_artculture_data = df_artculture_data.withColumnRenamed('freeEntryFlag','free_flag')
df_artculture_data = df_artculture_data.withColumnRenamed('frequencyStartDate','event_start_dt')
df_artculture_data = df_artculture_data.withColumnRenamed('frequencyEndDate','event_end_dt')
df_artculture_data = df_artculture_data.withColumnRenamed('nextOccurrence','event_date_pk')
df_artculture_data = df_artculture_data.withColumnRenamed('checkInTime','event_start_tm')
df_artculture_data = df_artculture_data.withColumnRenamed('checkOutTime','event_end_tm')
df_artculture_data = df_artculture_data.withColumnRenamed('productShortDescription','event_descrptn')
df_artculture_data = df_artculture_data.withColumnRenamed('productCategoryDescription','event_category')
df_artculture_data = df_artculture_data.withColumnRenamed('owningOrganisationName','event_own_org_nm')
df_artculture_data = df_artculture_data.withColumnRenamed('owningOrganisationNumber','event_own_org_num')
df_artculture_data = df_artculture_data.withColumnRenamed('australianBusinessNumber','event_org_abn')
df_artculture_data = df_artculture_data.withColumnRenamed('email','event_org_email')
df_artculture_data = df_artculture_data.withColumnRenamed('contact','event_org_contact')
df_artculture_data = df_artculture_data.withColumnRenamed('url','event_url')
df_artculture_data = df_artculture_data.withColumnRenamed('attributeIdFrequency','event_frequency')
df_artculture_data = df_artculture_data.withColumnRenamed('totalCapacity','event_size')
df_artculture_data.write.saveAsTable("events_landing.cra_artculture_api", format="parquet", mode="overwrite", path="/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_artculture_api")

#------------------------------------------------------------------------------------------------------------------

# Read leisure json 
# Read sub products jsons 
df_leisure_raw = sparksession.read.option("multiline","true").json("/Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventapi/leisure/product*.json")
# 'frequencyStartDate','frequencyEndDate', 'nextOccurrence','attributeIdFrequency' is not available in leisure data 
df_leisure = df_leisure_raw.select('productId','productName','freeEntryFlag','cityName', 'suburbName','stateName','areaName', 'countryName', 'productShortDescription','productCategoryDescription','owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','totalCapacity')
df_address_l = df_leisure_raw.select('addresses',col('productId').alias('pid'))
df_address_l = flatten_df(df_address_l)
df_addl_new = df_address_l.selectExpr( 'pid','addressLine1[0] as address1', 'geocodeGdaLatitude[0] as geolatitude','geocodeGdaLongitude[0] as geolongitude')
df_comm_l = df_leisure_raw.select('communication',col('productId').alias('pidc'))
df_comm_l = flatten_df(df_comm_l)

df_comm_l_new = df_comm_l.select('pidc','attributeIdCommunicationDescription','communicationDetail')
df_comm_l_new = df_comm_l_new.withColumn("email",get_email("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_l_new = df_comm_l_new.withColumn("contact",get_phone("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_l_new = df_comm_l_new.withColumn("url",get_url("attributeIdCommunicationDescription", "communicationDetail" ))
df_comm_l_new = df_comm_l_new.drop(df_comm_l_new.attributeIdCommunicationDescription)
df_comm_l_new = df_comm_l_new.drop(df_comm_l_new.communicationDetail)
#-----Join communication with address and time
df_combined_l = df_addl_new.join(df_comm_l_new, df_addl_new.pid == df_comm_l_new.pidc)
df_combined_l = df_combined_l.drop(df_combined_l.pidc)

#join events and address column 
df_leisure_new=df_leisure.join(df_combined_l,df_leisure.productId == df_combined_l.pid)
df_leisure_new = df_leisure_new.drop(df_leisure_new.pid)

df_leisure_data = df_leisure_new.select('productId','productName','areaName','address1','suburbName','cityName','stateName','countryName','geolatitude','geolongitude','freeEntryFlag', 'productShortDescription','productCategoryDescription','owningOrganisationName','owningOrganisationNumber','australianBusinessNumber','email','contact', 'url','totalCapacity')
#---- Add unique identifier for all columns hashing through sha2 and adding in column :unique_pid"--------------
df_leisure_data = df_leisure_data.withColumn("unique_pid", sha2(concat_ws("||", *df_leisure_data.columns), 512))
#------------------------------------------------------------------------------------------------------------------
df_leisure_data = df_leisure_data.withColumnRenamed('productId','event_prod_id')
df_leisure_data = df_leisure_data.withColumnRenamed('productName','event_nm')
df_leisure_data = df_leisure_data.withColumnRenamed('areaName','event_location')
df_leisure_data = df_leisure_data.withColumnRenamed('address1','event_street')
df_leisure_data = df_leisure_data.withColumnRenamed('suburbName','event_suburb')
df_leisure_data = df_leisure_data.withColumnRenamed('cityName','event_city')
df_leisure_data = df_leisure_data.withColumnRenamed('stateName','event_state')
df_leisure_data = df_leisure_data.withColumnRenamed('countryName','event_country')
df_leisure_data = df_leisure_data.withColumnRenamed('geolatitude','event_lat')
df_leisure_data = df_leisure_data.withColumnRenamed('geolongitude','event_long')
df_leisure_data = df_leisure_data.withColumnRenamed('freeEntryFlag','free_flag')
df_leisure_data = df_leisure_data.withColumnRenamed('productShortDescription','event_descrptn')
df_leisure_data = df_leisure_data.withColumnRenamed('productCategoryDescription','event_category')
df_leisure_data = df_leisure_data.withColumnRenamed('owningOrganisationName','event_own_org_nm')
df_leisure_data = df_leisure_data.withColumnRenamed('owningOrganisationNumber','event_own_org_num')
df_leisure_data = df_leisure_data.withColumnRenamed('australianBusinessNumber','event_org_abn')
df_leisure_data = df_leisure_data.withColumnRenamed('email','event_org_email')
df_leisure_data = df_leisure_data.withColumnRenamed('contact','event_org_contact')
df_leisure_data = df_leisure_data.withColumnRenamed('url','event_url')
df_leisure_data = df_leisure_data.withColumnRenamed('totalCapacity','event_size')
df_leisure_data.write.saveAsTable("events_landing.cra_leisure_api", format="parquet", mode="overwrite", path="/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_leisure_api")
archiveSourceFile()