from pyspark.sql import SparkSession
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.functions import col, collect_list, concat_ws, sha2
from pyspark.sql.functions import regexp_replace, regexp_extract, expr, when, lit
from pyspark.sql.functions import desc, row_number, monotonically_increasing_id
from pyspark.sql.window import Window
from pyspark.sql.functions import udf
from pyspark.sql.types import ArrayType, StringType
import pyspark.sql.functions as F
import os, subprocess
import re
import pyspark.sql.functions as psf


def blank_as_na(x):
    return when((col(x) != "") & (col(x) != "null") , col(x)).otherwise('Not Available')

def check_free_flag(x):
    return when((col(x) =='1') , "Yes").when((col(x) =='') , "Not Available").otherwise("No")

def is_blank_then_null(x):
    return when((col(x) != "") , col(x)).otherwise(None)


sparksession = (SparkSession
                .builder
                .appName("CRA-eventshistorc-curation")
                .enableHiveSupport()
                .getOrCreate())




# Read events landing 
df_hst_landing_event = sparksession.sql("SELECT unique_pid as pid,event_nm, event_street, event_suburb,event_location, event_lat, event_long, event_status,event_cs_status,event_date_pk,event_size  FROM events_landing.cra_events_historic")
df_hst_landing_event = df_hst_landing_event.withColumn('event_start_dt', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_end_dt', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_location', blank_as_na('event_location'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_street', blank_as_na('event_street'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_suburb', blank_as_na('event_suburb'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_city', lit('Canberra'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_state', lit('ACT'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_country', lit('AU'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_lat', df_hst_landing_event['event_lat'].cast(DoubleType()))
df_hst_landing_event = df_hst_landing_event.withColumn('event_long', df_hst_landing_event['event_long'].cast(DoubleType()))
df_hst_landing_event = df_hst_landing_event.withColumn('free_flag', lit("Yes"))
df_hst_landing_event = df_hst_landing_event.withColumn('event_date_pk', df_hst_landing_event['event_date_pk'].cast(DateType()))
df_hst_landing_event = df_hst_landing_event.withColumn('event_start_tm', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_end_tm', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_own_org_nm', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_own_org_num', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_org_abn', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_org_email', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_org_contact', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_url', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_frequency', lit(None))
df_hst_landing_event = df_hst_landing_event.withColumn('event_size', blank_as_na('event_size'))
df_hst_landing_event = df_hst_landing_event.withColumn('ACL_flag', lit('No'))
df_hst_landing_event = df_hst_landing_event.withColumn('market_flag', lit('No'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_status', blank_as_na('event_status'))
df_hst_landing_event = df_hst_landing_event.withColumn('event_cs_status', blank_as_na('event_cs_status'))
df_hst_landing_event_data = df_hst_landing_event.select('pid','event_nm', 'event_location', 'event_street', 'event_suburb', 'event_city', 'event_state', 'event_country', 'event_lat', 'event_long', 'free_flag','event_start_dt','event_end_dt','event_date_pk', 'event_start_tm', 'event_end_tm', 'event_status','event_cs_status','event_own_org_nm', 'event_own_org_num','event_org_abn','event_org_email','event_org_contact','event_url','event_frequency','event_size','ACL_flag', 'market_flag')

df_hst_curation_event = df_hst_landing_event_data.filter(df_hst_landing_event_data.event_cs_status !="Cancelled")

sparksession.saveToMapRDB(df_hst_curation_event, "/Data/CMTEDD/EconomicDevelopment/EventsACT/Curated/cra_events_historic", id_field_path = "pid", create_table = False, bulk_insert = False)