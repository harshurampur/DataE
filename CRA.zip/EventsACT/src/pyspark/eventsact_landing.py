from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType
import os, subprocess
from pyspark.sql.functions import sha2


sparksession = (SparkSession
                .builder
                .appName("CRA-eventsact-historic")
                .enableHiveSupport()
                .getOrCreate())


def checkSourceFile():
    ret = 0
    check_file_command = "hadoop fs -ls /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventhistoric/ | grep .csv | wc -l"
    ret = int(subprocess.check_output(check_file_command, shell=True))
    return ret


def archiveSourceFile():
    archive_file_command = "hadoop fs -cp -f /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventhistoric/*.csv /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -cp -f /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/*.xlsx /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -rm /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/*.xlsx"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -rm /Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventhistoric/*.csv"
    os.system(archive_file_command)
    print("Remove and Archive Source Files historic")
    return

# Read events csv 
if checkSourceFile() > 0:
    df_events_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/CMTEDD/EconomicDevelopment/EventsACT/SourceData/eventhistoric/*.csv")
    df_events = df_events_raw.select('Street','Town/City', 'Event Name', 'Event Status','Case Status', 'Marked Event Address','Perferred Event Date', 'Event Size', 'x', 'y')
    df_events = df_events.withColumn("unique_pid", sha2(concat_ws("||", *df_events.columns), 512))
    df_events = df_events.withColumnRenamed('Street','event_street')
    df_events = df_events.withColumnRenamed('Town/City','event_suburb')
    df_events = df_events.withColumnRenamed('Event Name','event_nm')
    df_events = df_events.withColumnRenamed('Event Status','event_status')
    df_events = df_events.withColumnRenamed('Case Status','event_cs_status')
    df_events = df_events.withColumnRenamed('Marked Event Address','event_location')
    df_events = df_events.withColumnRenamed('Perferred Event Date','event_date_pk')
    df_events = df_events.withColumnRenamed('Event Size','event_size')
    df_events = df_events.withColumnRenamed('x','event_long')
    df_events = df_events.withColumnRenamed('y','event_lat')
    df_events.write.saveAsTable("events_landing.cra_events_historic", format="parquet", mode="overwrite", path="/Data/CMTEDD/EconomicDevelopment/EventsACT/Landing/cra_events_historic")
    archiveSourceFile()