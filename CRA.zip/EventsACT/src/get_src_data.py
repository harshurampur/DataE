#! /usr/bin/env python

import requests
import json
from datetime import date,datetime
from dateutil.relativedelta import relativedelta
currentday= datetime.today().strftime('%Y-%m-%d')
six_months = (date.today() + relativedelta(months=+6)).strftime('%Y-%m-%d')

# events data
producturl = "{{ productidurl }}"
event_url ="{{ eventurl }}" + "&start="+ currentday +"&end="+ six_months
market_url ="{{ marketurl }}"+ "&start="+ currentday +"&end="+ six_months
art_url ="{{ arturl }}"+ "&start="+ currentday +"&end="+ six_months
culture_url = "{{ cultureurl }}"+ "&start="+ currentday +"&end="+ six_months
leisure_url="{{ leisureurl }}"+ "&start="+ currentday +"&end="+ six_months
path_for_json = "{{ api_path }}"
path_for_eventjson = "{{ event_path }}"
path_for_marketjson = "{{ market_path }}"
path_for_artculturejson = "{{ artculture_path }}"
path_for_leisurejson = "{{ leisure_path }}"

http_proxy  = "http://localhost:3128/"
https_proxy = "http://localhost:3128/"

proxyDict = {
              "http"  : http_proxy,
              "https" : https_proxy
            }

def get_requests(url):
    response = requests.get(url, proxies=proxyDict, verify=False)
    if response.status_code != 200:
        # This means something went wrong.
        raise ApiError('Bad Get Request {}'.format(response.status_code))
    print("Successfull Connection!")
    return response.json()

def writeproductids(data, pathforjson):
    for k,v in data.items():
        if k=='products':
            ids=v
            idxs=[]
            for a in ids:
                for key,item in a.items():
                    if key=="productId":
                        idxs.append(item)

    print(idxs)

    for ids in idxs:
        outfile= open(pathforjson+"product_id"+str(ids)+'.json', 'w')
        print(outfile)

        response=requests.get(producturl+ids, proxies=proxyDict, verify=False)
        json.dump(response.json(),outfile)
        outfile.close()


with open(path_for_json + 'events.json', 'w') as out_file:
    ds = get_requests(event_url)
    writeproductids(ds, path_for_eventjson)
    #out_file.write(ds.text)
    json.dump(ds, out_file)
    out_file.close()

with open(path_for_json + 'markets.json', 'w') as out_file:
    ds = get_requests(market_url)
    writeproductids(ds, path_for_marketjson)
    #out_file.write(ds.text)
    json.dump(ds, out_file)
    out_file.close()


with open(path_for_json + 'arts.json', 'w') as out_file:
    ds = get_requests(art_url)
    writeproductids(ds, path_for_artculturejson)
    #out_file.write(ds.text)
    json.dump(ds, out_file)
    out_file.close()

with open(path_for_json + 'culture.json', 'w') as out_file:
    ds = get_requests(culture_url)
    writeproductids(ds, path_for_artculturejson)
    #out_file.write(ds.text)
    json.dump(ds, out_file)
    out_file.close()

with open(path_for_json + 'leisure.json', 'w') as out_file:
    ds = get_requests(leisure_url)
    writeproductids(ds, path_for_leisurejson)
    #out_file.write(ds.text)
    json.dump(ds, out_file)
    out_file.close()
