#!/bin/bash
target_environment=$1
project_name=$2
sub_folder=$3
log_folder="$project_name"_log
mkdir -p ~/"$log_folder"


cd ~/$project_name/$sub_folder
echo "Start deploy of $sub_folder on datalake in $target_environment"
nohup ansible-playbook -i ~/sdld/inventory/$target_environment deployme.yml --vault-password-file=~/.av -e "sshuser=actadmin" -e "product_dir=$project_name" -e "sub_project=$sub_folder" 2>&1 | tee ~/"$log_folder"/"$sub_folder"_deploy_me-`date +%Y-%m-%d-%H:%M:%S`.out &