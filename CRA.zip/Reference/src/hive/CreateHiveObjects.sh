hive -e '
CREATE DATABASE IF NOT EXISTS cra_reference;

USE cra_reference;
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_suburb(
    pid INT,
	suburb_nm STRING,
	suburb_centrd_lat DECIMAL (9,6),
	suburb_centrd_lon DECIMAL (9,6),
	suburb_tccs_id STRING,
	suburb_dsply_ordr INT
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_suburb/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_precinct(
	pid INT,
	precinct_nm STRING,
	district_nm STRING,
	precinct_dsply_ordr INT,
	precinct_shrt_nm STRING,
	precinct_centrd_lat DECIMAL (9,6),
	precinct_centrd_lon DECIMAL (9,6)
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_precinct/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_domains(
	pid INT,
	domain_nm STRING,
	domain_descr STRING,
	domain_dsply_ordr INT,
    domain_shrt_cd STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_domains/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
	
CREATE EXTERNAL TABLE IF NOT EXISTS cra_indicators(
	pid INT,
	domain_nm STRING,
	success_indctr STRING,
	indctr_smry STRING,
	indctr_dsply_ordr INT,
	indctr_shrt_nm STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_indicators/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");

CREATE EXTERNAL TABLE IF NOT EXISTS cra_measures(
	pid INT,
	domain_nm STRING,
	indctr_nm STRING,
	measure_ph INT,
	measure_nm STRING,
    measure_shrt_nm STRING,
    measure_defn STRING,
    measure_prty STRING,
    measure_actv_flg STRING,
    measure_dsply_ordr INT
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_measures/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
'