from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType

sparksession = (SparkSession
                .builder
                .appName("CRAReference")
                .enableHiveSupport()
                .getOrCreate())

# Read Suburb csv 
df_suburb_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/Reference/Landing/suburbs.csv")
df_suburb = df_suburb_raw.select(col("SuburbDisplayOrder").alias("pid"),'SuburbName','SuburbCentroidLatitude', 'SuburbCentroidLongitude', 'SuburbTCCSId', 'SuburbDisplayOrder')
df_suburb = df_suburb.withColumnRenamed('SuburbName','suburb_nm')
df_suburb = df_suburb.withColumnRenamed('SuburbCentroidLatitude','suburb_centrd_lat')
df_suburb = df_suburb.withColumnRenamed('SuburbCentroidLongitude','suburb_centrd_lon')
df_suburb = df_suburb.withColumnRenamed('SuburbTCCSId','suburb_tccs_id')
df_suburb = df_suburb.withColumnRenamed('SuburbDisplayOrder','suburb_dsply_ordr')
df_suburb.write.saveAsTable("cra_reference.cra_suburb", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_suburb")

#---Read Precinct csv -- 
df_precinct_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/Reference/Landing/precinctsubprecincts.csv")
df_precinct = df_precinct_raw.select(col("PrecinctDisplayOrder").alias("pid"),'PrecinctName', 'DistrictName', 'PrecinctCentroidLatitude', 'PrecinctCentroidLongitude', 'PrecinctShortName', 'PrecinctDisplayOrder')
df_precinct = df_precinct.withColumnRenamed('PrecinctName','precinct_nm')
df_precinct = df_precinct.withColumnRenamed('DistrictName','district_nm')
df_precinct = df_precinct.withColumnRenamed('PrecinctCentroidLatitude','precinct_centrd_lat')
df_precinct = df_precinct.withColumnRenamed('PrecinctCentroidLongitude','precinct_centrd_lon')
df_precinct = df_precinct.withColumnRenamed('PrecinctShortName','precinct_shrt_nm')
df_precinct = df_precinct.withColumnRenamed('PrecinctDisplayOrder','precinct_dsply_ordr')
df_precinct.write.saveAsTable("cra_reference.cra_precinct", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_precinct")

#---Read domains csv -- 
df_domain_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/Reference/Landing/domains.csv")
df_domain = df_domain_raw.select(col("DomainDisplayOrder").alias("pid"),'DomainName', 'DomainDescription', 'DomainDisplayOrder', 'DomainShortCode')
df_domain = df_domain.withColumnRenamed('DomainName','domain_nm')
df_domain = df_domain.withColumnRenamed('DomainDescription','domain_descr')
df_domain = df_domain.withColumnRenamed('DomainShortCode','domain_shrt_cd')
df_domain = df_domain.withColumnRenamed('DomainDisplayOrder','domain_dsply_ordr')
df_domain.write.saveAsTable("cra_reference.cra_domains", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_domains")

#---Read indicators csv -- 
df_indicator_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/Reference/Landing/indicators.csv")
df_indicator = df_indicator_raw.select(col("IndicatorDisplayOrder").alias("pid"),'DomainName','Success Indicators', 'Indicator Summary', 'IndicatorDisplayOrder', 'IndicatorShortName')
df_indicator = df_indicator.withColumnRenamed('DomainName','domain_nm')
df_indicator = df_indicator.withColumnRenamed('Success Indicators','success_indctr')
df_indicator = df_indicator.withColumnRenamed('Indicator Summary','indctr_smry')
df_indicator = df_indicator.withColumnRenamed('IndicatorShortName','indctr_shrt_nm')
df_indicator = df_indicator.withColumnRenamed('IndicatorDisplayOrder','indctr_dsply_ordr')
df_indicator.write.saveAsTable("cra_reference.cra_indicators", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_indicators")


#---Read measures csv -- 
df_measures_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("delimiter", ",").option("multiline","true").option("quote", "\"").option("escape", "\"").option("encoding", "UTF-8").csv("/Data/EPSDD/CityRenewalAuthority/Reference/Landing/measures.csv")
df_measures = df_measures_raw.select(col("MeasureDisplayOrder").alias("pid"),'DomainName','IndicatorName', 'Phase', 'MeasureName','MeasureShortName','MeasureDefiniton','MeasurePriority', 'ActiveFlag', 'MeasureDisplayOrder')
df_measures = df_measures.withColumnRenamed('DomainName','domain_nm')
df_measures = df_measures.withColumnRenamed('IndicatorName','indctr_nm')
df_measures = df_measures.withColumnRenamed('Phase','measure_ph')
df_measures = df_measures.withColumnRenamed('MeasureName','measure_nm')
df_measures = df_measures.withColumnRenamed('MeasureShortName','measure_shrt_nm')
df_measures = df_measures.withColumnRenamed('MeasureDefiniton','measure_defn')
df_measures = df_measures.withColumnRenamed('MeasurePriority','measure_prty')
df_measures = df_measures.withColumnRenamed('ActiveFlag','measure_actv_flg')
df_measures = df_measures.withColumnRenamed('MeasureDisplayOrder','measure_dsply_ordr')
df_measures.write.saveAsTable("cra_reference.cra_measures", format="parquet", mode="overwrite", path="/Data/EPSDD/CityRenewalAuthority/Reference/Curated/cra_measures")