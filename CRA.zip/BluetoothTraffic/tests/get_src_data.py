#! /usr/bin/env python

import requests
import csv

# query only 2020 data
url = "{{ trafficurl }}"
path_for_CSV = "{{ hadoop_path }}"

http_proxy  = "http://localhost:3128/"
https_proxy = "http://localhost:3128/"

proxyDict = {
              "http"  : http_proxy,
              "https" : https_proxy
            }

def get_requests(url):
    response = requests.get(url, proxies=proxyDict)
    if response.status_code != 200:
        # This means something went wrong.
        raise ApiError('Bad Get Request {}'.format(response.status_code))
    print("Successfull Connection!")
    return response.json()


def get_file_name(data):
    today_date=data['features'][0]['properties']['IntervalStart']
    file_name=today_date.split('T')[0]+"_traffic.csv"
    return file_name


ds=get_requests(url)
filename=path_for_CSV + get_file_name(ds)
with open(filename, 'a+') as out_file:
    new_properties={}
    coordinates={}
    csv_write= csv.writer(out_file, delimiter=',')
    if out_file.tell()==0:
        csv_write.writerow(["Id", "Name", "Timestamp", "OriginSiteId", "DestSiteId", "MinTimeTaken(s)", "TimeTaken(s)", "Delay(s)", "ExcessDelay", "Speed", "Congestion", "Length(m)", "Direction", "LineCoOrdinates"])
    for elem in ds['features']:
        new_properties=elem['properties']
        coordinates=elem['geometry']
        csv_write.writerow([new_properties["Id"], new_properties["Name"], new_properties["IntervalStart"], new_properties["OriginSiteId"], new_properties["DestSiteId"], new_properties["MinTT"], new_properties["TT"], new_properties["Delay"], new_properties["ExcessDelay"], new_properties["Speed"], new_properties["Congestion"], new_properties["Length"], new_properties["Direction"], coordinates["coordinates"]])
    print("finished")
