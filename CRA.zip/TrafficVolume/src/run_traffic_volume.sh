#!/bin/bash
log_dir=$1
currentDateTime=$(date)
# strCurrentDateTime=$(date -d "$currentDateTime" +'%Y-%m-%d %H:%M:%S')
log_file="$log_dir/CRA_TrafficVolume_$(date -d "$currentDateTime" +'%Y%m%d%H%M%S').log"

echo "Running TrafficVolume Processing" >> "$log_file"

Source_Path_processing="{{ source_path }}"
isEmpty=$(hadoop fs -ls  $Source_Path_processing*.txt -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Start Source Processing" >> "$log_file"
    source /opt/miniconda3/bin/activate /home/mapr/envs/{{ conda_env }};
    python /tmp/CRA/TrafficVolume/get_src_data.py >> "$log_file"
    source /opt/miniconda3/bin/deactivate
    echo "Source Processing Completed" >> "$log_file"
else
    echo "Not found csvs for processing" >> "$log_file"
fi


echo "Running TrafficVolume Landing" >> "$log_file"

Source_Path_process="{{ processing_path }}"
isEmpty=$(hadoop fs -ls  $Source_Path_process*.csv -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Running pyspark landing volume" >> "$log_file"
    /opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/TrafficVolume/pyspark/trafficvol_landing.py 2>&1>> "$log_file"
else
    echo "Not found." >> "$log_file"
fi

Source_Path="{{ source_path }}"
isEmpty=$(hadoop fs -ls  $Source_Path*.csv -R 2>/dev/null | grep -E '^-' | wc -l)
if [ $isEmpty -ne 0 ]
then
    echo "Running pyspark landing reference" >> "$log_file"
    /opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/TrafficVolume/pyspark/trafficvol_ref_landing.py 2>&1>> "$log_file"
else
    echo "Not found." >> "$log_file"
fi



sleep 10s

echo "Running Curation TrafficVolume" >> "$log_file"
/opt/mapr/spark/spark-2.2.1/bin/spark-submit --master yarn --num-executors 4 --executor-memory 1G --conf spark.ui.enabled=true --conf spark.executor.pyspark.memory=3G /tmp/CRA/TrafficVolume/pyspark/trafficvol_curated.py 2>&1>> "$log_file"
echo "Curation TrafficVolume Completed" >> "$log_file"


echo "Job completed" >> "$log_file"