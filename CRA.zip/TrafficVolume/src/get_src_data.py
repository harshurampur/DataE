#! /usr/bin/env python

import pandas as pd
import csv
import time
import glob
import os
from os.path import basename

source_path="{{ source_path }}"
processing_path="{{ processing_path }}"

def isTimeFormat(input):
    try:
        time.strptime(input, '%H:%M')
        return True
    except ValueError:
        return False

def convertTocsvs():
    df_traf_transformed = pd.DataFrame(columns = ['TrafficVolDate','TrafficDay','TrafficTimeStamp','ApproachNum', 'TrafficVolumeCount'])
    monthlist=["January","February","March","April","May","June","July","August","September","October","November","December"]
    for infile in sorted(glob.glob(source_path+'*.txt')):
        infile_csv = os.path.splitext(basename(infile))[0] +".csv"
        with open(infile, newline = '\n') as traf_file:
            trafficdata = csv.reader(traf_file, delimiter='\t')

            for line_data in trafficdata:
                for lines in line_data:
                    data = lines.split()
                    if len(data)>3:
                        if data[2] in monthlist:
                            Traffic_Day = (data[0].split(","))[0]
                            Traffic_Date = " ".join(data[1:])
                        if isTimeFormat(data[0]):
                            df_traf_transformed = df_traf_transformed.append({'TrafficVolDate': Traffic_Date,
                                                                      'TrafficDay': Traffic_Day,
                                                                      'TrafficTimeStamp': data[0],
                                                                      'ApproachNum': " ".join(data[1:3]),
                                                                      'TrafficVolumeCount': data[3]
                                                                     }, ignore_index=True)
                        # 24:00 is not time format in python
                        elif data[0] == "24:00":
                            df_traf_transformed = df_traf_transformed.append({'TrafficVolDate': Traffic_Date,
                                                                      'TrafficDay': Traffic_Day,
                                                                      'TrafficTimeStamp': data[0],
                                                                      'ApproachNum': " ".join(data[1:3]),
                                                                      'TrafficVolumeCount': data[3]
                                                                     }, ignore_index=True)
            traf_file.close()
        df_traf_transformed.to_csv(processing_path+infile_csv)
        print("Finished Writing one file")
        df_traf_transformed = pd.DataFrame(columns = ['TrafficVolDate','TrafficDay','TrafficTimeStamp','ApproachNum', 'TrafficVolumeCount'])
    return

convertTocsvs()
