from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType
import os, subprocess
from pyspark.sql.functions import sha2


sparksession = (SparkSession
                .builder
                .appName("Traffic-Volume-Count")
                .enableHiveSupport()
                .getOrCreate())

def archiveSourceFile():
    archive_file_command = "hadoop fs -cp -f /Data/TCCS/TrafficVolume/SourceData/*.txt /Data/TCCS/TrafficVolume/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -cp -f /Data/TCCS/TrafficVolume/SourceData/TrafficProcessing/*.csv /Data/TCCS/TrafficVolume/SourceData/Archive/"
    os.system(archive_file_command)
    archive_file_command = "hadoop fs -rm /Data/TCCS/TrafficVolume/SourceData/*.txt"
    os.system(archive_file_command)
    archive_rmfile_command = "hadoop fs -rm /Data/TCCS/TrafficVolume/SourceData/TrafficProcessing/*.csv"
    os.system(archive_rmfile_command)
    print("Remove and Archive Source Files")
    return

def checkSourceFile():
    ret = 0
    check_file_command = "hadoop fs -ls /Data/TCCS/TrafficVolume/SourceData/TrafficProcessing/ | grep .csv | wc -l"
    ret = int(subprocess.check_output(check_file_command, shell=True))
    return ret

# Read events csv 
if checkSourceFile() > 0:
    df_traffic_vol_cnt_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("multiline","true").csv("/Data/TCCS/TrafficVolume/SourceData/TrafficProcessing/*.csv")
    df_traffic_vol_cnt = df_traffic_vol_cnt_raw.select('TrafficVolDate','TrafficDay','TrafficTimeStamp', 'ApproachNum','TrafficVolumeCount')
    df_traffic_vol_cnt = df_traffic_vol_cnt.withColumnRenamed('TrafficVolDate','trafficvol_dt')
    df_traffic_vol_cnt = df_traffic_vol_cnt.withColumnRenamed('TrafficDay','trafficvol_day')
    df_traffic_vol_cnt = df_traffic_vol_cnt.withColumnRenamed('TrafficTimeStamp','trafficvol_ts')
    df_traffic_vol_cnt = df_traffic_vol_cnt.withColumnRenamed('ApproachNum','approach_num')
    df_traffic_vol_cnt = df_traffic_vol_cnt.withColumnRenamed('TrafficVolumeCount','trafficvol_cnt')
    df_traffic_vol_cnt.write.saveAsTable("traffic_volume_landing.traffic_vol_count", format="parquet", mode="overwrite", path="/Data/TCCS/TrafficVolume/Landing/traffic_vol_count")
    
    archiveSourceFile()