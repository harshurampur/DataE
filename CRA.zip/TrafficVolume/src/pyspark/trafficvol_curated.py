from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.functions import regexp_replace, regexp_extract, expr, when, lit
from pyspark.sql.types import StringType, IntegerType
import os, subprocess
from pyspark.sql.functions import to_date,concat


sparksession = (SparkSession
                .builder
                .appName("Traffic-Volume-Count-Curated")
                .enableHiveSupport()
                .getOrCreate())




df_ref = sparksession.sql("SELECT  intrsctn_nm, intrsctn_lat, intrsctn_long, approach_num, approach_frm_st, approach_to_st, approach_desc, city_mv_desc, intrsctn_sub FROM traffic_volume_landing.traffic_vol_ref")
# remove all white spaces to match the column name in volume cnt 
df_ref_new = df_ref.select(regexp_replace(col("approach_num"),"\\s+", "").alias("approach_ref"),"intrsctn_nm", "intrsctn_lat", "intrsctn_long", "approach_frm_st", "approach_to_st", "approach_desc", "city_mv_desc", "intrsctn_sub")
df_cnt = sparksession.sql("SELECT trafficvol_dt, trafficvol_day, trafficvol_ts, approach_num, trafficvol_cnt FROM traffic_volume_landing.traffic_vol_count")
#cannot include TrafficVol date and Timestamp as the time is 24:00 not a valid to date function
#df_cnt = df_cnt.withColumn('joined_datetime', concat(col('trafficvol_dt'),lit(' '), col('trafficvol_ts')))
df_cnt_new = df_cnt.select(regexp_replace(col("approach_num"), "\\s+", "").alias("approach_pid"),to_date(col("trafficvol_dt"),"dd MMMM yyyy").alias("trafficvol_dt"),"trafficvol_day", "trafficvol_ts", "trafficvol_cnt", "approach_num")
df_traffic_vol_curated =df_cnt_new.join(df_ref_new,df_cnt_new.approach_pid == df_ref_new.approach_ref) 
df_traffic_vol_curated = df_traffic_vol_curated.drop(df_traffic_vol_curated.approach_pid)
df_traffic_vol_curated = df_traffic_vol_curated.drop(df_traffic_vol_curated.approach_ref)
df_traffic_vol_curated = df_traffic_vol_curated.withColumn("trafficvol_cnt", df_traffic_vol_curated["trafficvol_cnt"].cast(IntegerType()))
df_traffic_vol_curated.write.saveAsTable("traffic_volume_curated.traffic_vol_count_curated", format="parquet", mode="overwrite", path="/Data/TCCS/TrafficVolume/Curated/traffic_vol_count_curated")
   
