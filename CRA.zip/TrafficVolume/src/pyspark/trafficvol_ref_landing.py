from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, collect_list, concat_ws
from pyspark.sql.types import StringType
import os, subprocess
from pyspark.sql.functions import sha2


sparksession = (SparkSession
                .builder
                .appName("Traffic-Volume-Reference")
                .enableHiveSupport()
                .getOrCreate())


def checkSourceFile():
    ret = 0
    check_file_command = "hadoop fs -ls /Data/TCCS/TrafficVolume/SourceData/ | grep .csv | wc -l"
    ret = int(subprocess.check_output(check_file_command, shell=True))
    return ret

# Read events csv 
if checkSourceFile() > 0:
    df_traffic_ref_raw = sparksession.read.option("header",True).option("inferSchema", "true").option("multiline","true").csv("/Data/TCCS/TrafficVolume/SourceData/*.csv")
    df_traffic_ref = df_traffic_ref_raw.select('Intersection Name','IntersectionCentroidLatitude', 'IntersectionCentroidLongitude', 'ApproachNumber','ApproachFromSteet', 'ApproachToSteet','ApproachDescription', 'CityMovementDescription', 'IntersectionSuburb')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('Intersection Name','intrsctn_nm')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('IntersectionCentroidLatitude','intrsctn_lat')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('IntersectionCentroidLongitude','intrsctn_long')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('ApproachNumber','approach_num')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('ApproachFromSteet','approach_frm_st')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('ApproachToSteet','approach_to_st')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('ApproachDescription','approach_desc')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('CityMovementDescription','city_mv_desc')
    df_traffic_ref = df_traffic_ref.withColumnRenamed('IntersectionSuburb','intrsctn_sub')
    df_traffic_ref.write.saveAsTable("traffic_volume_landing.traffic_vol_ref", format="parquet", mode="overwrite", path="/Data/TCCS/TrafficVolume/Landing/traffic_vol_ref")
    