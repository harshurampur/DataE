hive -e '
CREATE DATABASE IF NOT EXISTS traffic_volume_landing;

USE traffic_volume_landing;
	
CREATE EXTERNAL TABLE IF NOT EXISTS traffic_vol_count(
    pid INT,
	trafficvol_dt DATE,
	trafficvol_day STRING,
	trafficvol_ts STRING,
	approach_num STRING,
	trafficvol_cnt INT
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/TCCS/TrafficVolume/Landing/traffic_vol_count/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");

CREATE DATABASE IF NOT EXISTS traffic_volume_curated;

USE traffic_volume_curated;
	
CREATE EXTERNAL TABLE IF NOT EXISTS traffic_vol_count_curated(
	trafficvol_dt DATE,
	trafficvol_day STRING,
	trafficvol_ts STRING,
	approach_num STRING,
	trafficvol_cnt INT,
    intrsctn_nm STRING,
    intrsctn_lat DECIMAL (9,6),
    intrsctn_long DECIMAL (9,6),
    approach_frm_st STRING,
    approach_to_st STRING,
    approach_desc STRING,
    city_mv_desc STRING,
    intrsctn_sub STRING
)
ROW FORMAT SERDE 
	"org.apache.hadoop.hive.serde2.avro.AvroSerDe"
STORED AS INPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerInputFormat"
OUTPUTFORMAT 
	"org.apache.hadoop.hive.ql.io.avro.AvroContainerOutputFormat"
LOCATION
	"maprfs:/Data/TCCS/TrafficVolume/Curated/traffic_vol_count_curated/"
TBLPROPERTIES (
	"numFiles"="0",
	"totalSize"="0",
	"transient_lastDdlTime"="1541641978");
'